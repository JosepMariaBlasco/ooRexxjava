#/*----------------------------------------------------------------------------*/
#/*                                                                            */
#/* Copyright (c) 2014-2026 Rexx Language Association. All rights reserved.    */
#/*                                                                            */
#/* This program and the accompanying materials are made available under       */
#/* the terms of the Common Public License v1.0 which accompanies this         */
#/* distribution. A copy is also available at the following address:           */
#/* https://www.oorexx.org/license.html                                        */
#/*                                                                            */
#/* Redistribution and use in source and binary forms, with or                 */
#/* without modification, are permitted provided that the following            */
#/* conditions are met:                                                        */
#/*                                                                            */
#/* Redistributions of source code must retain the above copyright             */
#/* notice, this list of conditions and the following disclaimer.              */
#/* Redistributions in binary form must reproduce the above copyright          */
#/* notice, this list of conditions and the following disclaimer in            */
#/* the documentation and/or other materials provided with the distribution.   */
#/*                                                                            */
#/* Neither the name of Rexx Language Association nor the names                */
#/* of its contributors may be used to endorse or promote products             */
#/* derived from this software without specific prior written permission.      */
#/*                                                                            */
#/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        */
#/* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          */
#/* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          */
#/* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   */
#/* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      */
#/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED   */
#/* TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,        */
#/* OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY     */
#/* OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING    */
#/* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS         */
#/* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.               */
#/*                                                                            */
#/*----------------------------------------------------------------------------*/


#/*----------------------------------------------------------------------------*/
#/* Global settings                                                            */
#/*----------------------------------------------------------------------------*/
message(STATUS "CMake version is ${CMAKE_VERSION}")
if (APPLE)
    # macOS builds with cmake prior version 3.12 have an alleged @rpath issue
    cmake_minimum_required (VERSION 3.12...99.99)
elseif (WIN32)
    # Windows
    # CMP0091 introduced in 3.15 must stay OLD for our /MD -> /MT hack to work
    cmake_minimum_required (VERSION 2.8.12...3.14)
else ()
    # for other platforms
    cmake_minimum_required (VERSION 2.8.12...99.99)
endif ()

# CMP0069 must be NEW before check_ipo_supported() will run at all: under OLD it
# only ever adds IPO flags for the Intel compiler on Linux, and the check itself
# raises a fatal error. See the IPO block further down. The policy and the
# CheckIPOSupported module both arrived in CMake 3.9, so guard for older CMake
# (e.g. 3.5 on Ubuntu 16.04), which does not know the policy and errors on it.
if (POLICY CMP0069)
  cmake_policy(SET CMP0069 NEW)
endif ()

# must come before the project command
# 10.13.6 High Sierra is the minimum system supported
if( APPLE AND BUILD_OSX_UNIVERSAL_BINARIES )
  set( CMAKE_OSX_DEPLOYMENT_TARGET 10.13.6 CACHE STRING  "" FORCE)
endif()

project (ooRexx)

if( APPLE AND BUILD_OSX_UNIVERSAL_BINARIES )
  set( CMAKE_OSX_ARCHITECTURES arm64 x86_64 )
endif()

include(CheckIncludeFile)
include(CheckLibraryExists)
include(CheckFunctionExists)
include(CheckSymbolExists)
include(CheckCSourceCompiles)
include(CheckStructHasMember)
include(GNUInstallDirs)
set (CMAKE_LIBRARY_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/lib)
set (CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/bin)
set (CMAKE_ARCHIVE_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/lib)
set (CMAKE_PDB_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/bin)
set (CMAKE_SAMPLES_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/samples)
#/*----------------------------------------------------------------------------*/
#/* Project settings                                                           */
#/*----------------------------------------------------------------------------*/
# The version of ooRexx to make
set (ORX_API_LEVEL 4)
set (ORX_MAJOR 5)
set (ORX_MINOR 3)
set (ORX_MOD_LVL 0)
set (ORX_BLD_LVL 0)
set (ORX_VERSION ${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL})
set (ORX_NODOT_VERSION ${ORX_MAJOR}${ORX_MINOR}${ORX_MOD_LVL})
set (ORX_VER_STR ${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL})
string(TIMESTAMP ORX_YEAR %Y)
set (ORX_COPY_YEAR 2005-${ORX_YEAR})
string(TOUPPER ${CMAKE_SYSTEM_NAME} ORX_SYS_STR)

# Platform independent architecture test
if (CMAKE_SIZEOF_VOID_P MATCHES 8)
    set(ORX_ARCHITECTURE "64")
    message(STATUS "Building for a 64-bit architecture")
else ()
    set(ORX_ARCHITECTURE "32")
    message(STATUS "Building for a 32-bit architecture")
endif ()


# Unix: used in macro create_install_symlink()
set(SYM_LINK_CREATE_FROM     3)                # define lower bound
math(EXPR SYM_LINK_CREATE_TO "${ORX_API_LEVEL}-1") # define upper bound is dependent on ${ORX_MAJOR}


# OOREXX_SHEBANG_PROGRAM default:
set (OOREXX_SHEBANG_PROGRAM "/usr/bin/env rexx")

# if ORX_SHEBANG defined change default shebang accordingly
if (ORX_SHEBANG)
   if (${ORX_SHEBANG} STREQUAL "1")
      # set hard coded path to installation directory
      if (WIN32)
         # Windows does not use the shebang, let the default stay
         message(STATUS "OOREXX_SHEBANG_PROGRAM: \"${OOREXX_SHEBANG_PROGRAM}\" (default: \"-DORX_SHEBANG=1\" gets ignored on Windows)")
      else ()
         if (APPLE)
            # APPLE-special: install into homedirectory's Applications folder
            set (OOREXX_SHEBANG_PROGRAM "$ENV{HOME}/Applications/ooRexx${ORX_MAJOR}/bin/rexx")
         else ()
            set (OOREXX_SHEBANG_PROGRAM "${CMAKE_INSTALL_PREFIX}/bin/rexx")
         endif ()
         message(STATUS "OOREXX_SHEBANG_PROGRAM: \"${OOREXX_SHEBANG_PROGRAM}\" (ORX_SHEBANG=1 hence hardcoded to installation directory)")
      endif ()
   else ()
      # use supplied string verbatim; note: the shebang "#!" is already supplied in the sample Rexx file
      set (OOREXX_SHEBANG_PROGRAM "${ORX_SHEBANG}")
      message(STATUS "OOREXX_SHEBANG_PROGRAM: \"${OOREXX_SHEBANG_PROGRAM}\" (value supplied via ORX_SHEBANG)")
   endif ()
else ()
    message(STATUS "OOREXX_SHEBANG_PROGRAM: \"${OOREXX_SHEBANG_PROGRAM}\" (default)")
endif()

find_package(Subversion)
if(SUBVERSION_FOUND)
set(ORX_WC_REVISION 0)
Subversion_WC_INFO(${PROJECT_SOURCE_DIR} ORX IGNORE_SVN_FAILURE)
if (NOT "${ORX_WC_LAST_CHANGED_REV}" STREQUAL "")
set(ORX_BLD_LVL ${ORX_WC_LAST_CHANGED_REV})
message(STATUS "Revision Number from SVN...")
endif()
endif()
message(STATUS "Revision Number is ${ORX_BLD_LVL}")

FIND_PROGRAM(XALAN_EXECUTABLE Xalan
   DOC "Xalan command line xslt converter")
message(STATUS "XALAN_EXECUTABLE is ${XALAN_EXECUTABLE}")

# The following supports the versioning of the rexx shared libraries
# This defines the oorexx library version. For ooRexx this should always be the
# same as the ORX_MAJOR number.
set (ORX_CURRENT ${ORX_MAJOR})
# Each public release of ooRexx should increment this number by one except
# when the ORX_MINOR goes back to zero. If that is the case then this entry
# should also be set to zero.
set (ORX_REVISION 1)
# For ooRexx, this number should ALWAYS be zero. This will force the linker to
# utilize all previous releases for linking.
set (ORX_AGE 0)
# Please note that the version-info has nothing to do with the release version.
# You need to know exactly what you are doing in order to get this correct.
set (VERSION_INFO "-version-info ${ORX_CURRENT}:${ORX_REVISION}:${ORX_AGE}")
# This is version information set on library properties
set (ORX_VERSION ${ORX_CURRENT}.${ORX_AGE}.${ORX_REVISION})


# WebAssembly builds: Emscripten (browser, Node) and WASI (any WASI runtime)
if (EMSCRIPTEN OR CMAKE_SYSTEM_NAME STREQUAL "WASI")
   set (ORX_WASM TRUE)
   add_compile_definitions(ORX_WASM)
endif ()
if (CMAKE_SYSTEM_NAME STREQUAL "WASI")
   set (ORX_WASI TRUE)
endif ()
# Set the platform subdirectory name
if (WIN32)
   set (ORX_PLATFORM_DIR platform/windows)
   set (ORX_IMAGE_OUTPUT_LOCATION ${CMAKE_RUNTIME_OUTPUT_DIRECTORY})
else ()
   set (ORX_PLATFORM_DIR platform/unix)
   if (ORX_WASM)
      # The WASM runtime embeds the image from the executable output directory.
      set (ORX_IMAGE_OUTPUT_LOCATION ${CMAKE_RUNTIME_OUTPUT_DIRECTORY})
   else ()
      set (ORX_IMAGE_OUTPUT_LOCATION ${CMAKE_LIBRARY_OUTPUT_DIRECTORY})
   endif ()
endif ()
# Set path to look for include files
include_directories(BEFORE api api/${ORX_PLATFORM_DIR})


# defining ORX_REXXPATH will set a default for the REXX_PATH environment variable
if (ORX_REXXPATH)
    message(STATUS "Setting REXX_PATH default to ${ORX_REXXPATH}")
    set (CMAKE_REXXPATH ${ORX_REXXPATH})
endif ()


# Common install variables
   SET(CPACK_PACKAGE_VERSION_MAJOR ${ORX_MAJOR})
   SET(CPACK_PACKAGE_VERSION_MINOR ${ORX_MINOR})
   SET(CPACK_PACKAGE_VERSION_PATCH ${ORX_MOD_LVL})
   set(CPACK_PACKAGE_NAME "oorexx")
   set(CPACK_PACKAGE_LONG_NAME "Open Object Rexx")
   set(CPACK_PACKAGE_VENDOR "Rexx Language Association")
   set(CPACK_PACKAGE_DESCRIPTION_FILE ${CMAKE_SOURCE_DIR}/ReleaseNotes)
   set(CPACK_PACKAGE_DESCRIPTION_SUMMARY "Open Object Rexx Interpreter")
   set(CPACK_RESOURCE_FILE_LICENSE ${CMAKE_SOURCE_DIR}/CPLv1.0.txt)
   set(CPACK_RESOURCE_FILE_README ${CMAKE_SOURCE_DIR}/ReleaseNotes)

# Set install variables
if (WIN32)
   # NOTE: specifying "." for the destination will place the files in the
   # root directory of the NSIS install.  This needs to be a "." to get
   # the files in the correct location.
   set (INSTALL_EXECUTABLE_DIR .)
   set (INSTALL_LIB_DIR .)
   set (INSTALL_CLS_DIR .)
   set (INSTALL_DOC_DIR doc)
   set (INSTALL_INCLUDE_DIR api)
   set (INSTALL_SAMPLES_DIR samples)

# NSIS builder locations

   # locations of NSIS directories.  The first is where we build from,
   # the second is source for any template files for configuring the build.
   set(NSIS_INSTALLER_DIR ${CMAKE_CURRENT_BINARY_DIR}/NSIS)
   set(NSIS_INSTALLER_SOURCE_DIR ${CMAKE_CURRENT_SOURCE_DIR}/${ORX_PLATFORM_DIR}/install)

   # NSIS version identifier that includes the build level
   set (ORX_VERSION_NSIS ${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL}-${ORX_BLD_LVL})

   # The DOC source dir is usually specified in native form...need to convert it
   # to the CMAKE format for the install commands.
   if (DOC_SOURCE_DIR)
      file(TO_CMAKE_PATH ${DOC_SOURCE_DIR} DOC_SOURCE_DIR)
   endif ()

   # location where we assemble everything to build the installer
   set (NSIS_BUILD_DIR ${CMAKE_CURRENT_BINARY_DIR}/NSIS)
   # location for pulling together the install file set
   set (NSIS_FILE_DIR ${CMAKE_CURRENT_BINARY_DIR}/NSIS/files)

   # Create and add a shortcut item to the list for a component
   # This also adds entries to delete the equivalent shortcut
   MACRO(install_component_shortcut component name prog arg icon icon_index)
     set(NSIS_COMPONENT_SHORTCUTS_${component} "${NSIS_COMPONENT_SHORTCUTS_${component}}\n!insertmacro ConfigureShortCut \"${name}\" ${prog} \"${arg}\" ${icon} \"${icon_index}\"")
   ENDMACRO ()

   # Create and add a shortcut item to the list for a component for running a rexx program
   # This also adds entries to delete the equivalent shortcut
   MACRO(install_rexx_shortcut component name launcher program)
     set(NSIS_COMPONENT_SHORTCUTS_${component} "${NSIS_COMPONENT_SHORTCUTS_${component}}\n!insertmacro ConfigureRexxShortCut \"${name}\" ${launcher} \"${program}\"")
   ENDMACRO ()

   # Create and add a shortcut for a documentation element
   # This also adds entries to delete the equivalent shortcut
   MACRO(install_doc_shortcut name file)
     set(NSIS_COMPONENT_SHORTCUTS_Docs "${NSIS_COMPONENT_SHORTCUTS_Docs}\n!insertmacro ConfigureDocShortCut \"${name}\" \"${file}\"")
   ENDMACRO ()

else ()

   # To ensure the required libraries are always found, regardless of whether
   # executables are run directly from the build tree or after installation, we
   # use settings similar to what is suggested in "Always full RPATH" at:
   # https://gitlab.kitware.com/cmake/community/-/wikis/doc/cmake/RPATH-handling

   # use (i.e. don't skip) the full RPATH for the build tree
   set (CMAKE_SKIP_BUILD_RPATH FALSE)

   # when building, don't use the install RPATH already (only later when installing)
   set (CMAKE_BUILD_WITH_INSTALL_RPATH FALSE)

   if (APPLE)
       SET (CMAKE_INSTALL_RPATH "@executable_path/../lib;@executable_path/../Libraries")
   else ()
       # using $ORIGIN/.. instead of ${CMAKE_INSTALL_PREFIX} allows the package
       # to be relocated during installation, but this comes at a cost: we can't
       # be sure that all platforms we intend to run on really support $ORIGIN
       SET (CMAKE_INSTALL_RPATH "$ORIGIN/../${CMAKE_INSTALL_LIBDIR}")
   endif ()

   # add the automatically determined parts of the RPATH
   # which point to directories outside the build tree to the install RPATH
   set (CMAKE_INSTALL_RPATH_USE_LINK_PATH TRUE)

   # if the user didn't specify a CMAKE_INSTALL_PREFIX we override the CMake
   # default on Apple Darwin to $HOME/Applications/ooRexx5
   if (APPLE AND CMAKE_INSTALL_PREFIX_INITIALIZED_TO_DEFAULT)
     set (CMAKE_INSTALL_PREFIX $ENV{HOME}/Applications/ooRexx${ORX_MAJOR}
       CACHE PATH "Default install path" FORCE)
     set (INSTALL_LIB_DIR lib)
   else ()
     set (INSTALL_LIB_DIR ${CMAKE_INSTALL_LIBDIR})
   endif ()
   message(STATUS "CMAKE_INSTALL_PREFIX is ${CMAKE_INSTALL_PREFIX}")
   message(STATUS "INSTALL_LIB_DIR is ${INSTALL_LIB_DIR}")

   set (INSTALL_EXECUTABLE_DIR bin)
   set (INSTALL_CLS_DIR ${INSTALL_EXECUTABLE_DIR})
   set (INSTALL_INCLUDE_DIR include)
   set (INSTALL_SAMPLES_DIR share/${CMAKE_PROJECT_NAME}/samples)
   set (INSTALL_DOC_DIR share/${CMAKE_PROJECT_NAME}/doc)
   set (INSTALL_MAN_DIR share/man)
endif ()

# Set compiler and linker flags common to all build environments
# current trunk uses the C++ "override" keyword, which requires C++11
if (CMAKE_VERSION VERSION_LESS "3.1")
  if (CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
    set (CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -std=gnu++11")
  endif ()
else ()
  set (CMAKE_CXX_STANDARD 11)
  if (CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
    set (CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -fno-lifetime-dse")
  endif ()
endif ()

# Interprocedural optimization, also known as link time optimization.
#
# This was enabled once before, in r13047, and reverted ten days later in r13049
# because release builds segfaulted on Linux while running the test suite: the
# reported failure was in Alarm.testGroup, it moved around from run to run, and
# macOS and Windows were unaffected. A non-deterministic crash that changes
# location is what latent undefined behaviour looks like once the optimiser is
# allowed to inline across translation units, so it is worth trying again now
# that a few such defects have been found and fixed rather than assuming IPO
# itself is at fault.
#
# ORX_ENABLE_IPO exists so that turning this off is a matter of flipping a
# default rather than deleting the block again. Whoever needs it off next should
# not have to write a revert.
option (ORX_ENABLE_IPO "Use interprocedural optimization when the compiler supports it" ON)

# WebAssembly: no IPO.  With LTO the final code generation happens in the
# linker without -fwasm-exceptions, and every catch is lost (found building
# for WASI: 0 try_table in the binary, any Rexx error ends the program).
if (ORX_ENABLE_IPO AND NOT ORX_WASM AND NOT CMAKE_VERSION VERSION_LESS "3.9")
  include (CheckIPOSupported)
  check_ipo_supported (RESULT ipo_supported OUTPUT ipo_output)
  if (ipo_supported)
    # A Debug build wants to be debuggable, and cross-module inlining is the
    # opposite of that.
    if (CMAKE_BUILD_TYPE STREQUAL "Debug")
      message (STATUS "IPO is supported but is not used for a Debug build")
      set (CMAKE_INTERPROCEDURAL_OPTIMIZATION FALSE)
    else ()
      message (STATUS "IPO is supported and enabled")
      set (CMAKE_INTERPROCEDURAL_OPTIMIZATION TRUE)
    endif ()
  else ()
    message (STATUS "IPO is not supported by this toolchain: ${ipo_output}")
    set (CMAKE_INTERPROCEDURAL_OPTIMIZATION FALSE)
  endif ()
elseif (ORX_ENABLE_IPO)
  # CheckIPOSupported and policy CMP0069 both require CMake 3.9. Older CMake
  # (e.g. 3.5 on Ubuntu 16.04) cannot detect or enable IPO, so build without it.
  message (STATUS "IPO requested but requires CMake 3.9 or later; this is ${CMAKE_VERSION}, building without IPO")
  set (CMAKE_INTERPROCEDURAL_OPTIMIZATION FALSE)
else ()
  message (STATUS "IPO disabled by ORX_ENABLE_IPO")
  set (CMAKE_INTERPROCEDURAL_OPTIMIZATION FALSE)
endif ()

include_directories(${PROJECT_BINARY_DIR})
if (WIN32)
   if (${ORX_ARCHITECTURE} STREQUAL "64")
      set (EXE_MANIFEST_FILE ${CMAKE_CURRENT_SOURCE_DIR}/${ORX_PLATFORM_DIR}/rexx64.exe.manifest)
      set (NSIS_CPU "x86_64")
   else ()
      set (EXE_MANIFEST_FILE ${CMAKE_CURRENT_SOURCE_DIR}/${ORX_PLATFORM_DIR}/rexx32.exe.manifest)
      set (NSIS_CPU "x86_32")
   endif ()
   file(TO_NATIVE_PATH ${EXE_MANIFEST_FILE} EXE_MANIFEST_FILE)
   set (CMAKE_EXE_LINKER_FLAGS "${CMAKE_EXE_LINKER_FLAGS} /STACK:8388608")

   # tell rc.exe to suppress its banner: assume support for -nologo since VS 16.0
   if (${MSVC_VERSION} GREATER 1818)
      set (CMAKE_RC_FLAGS "-nologo")
   endif ()

   add_definitions(/DORX_VER=${ORX_MAJOR}
            /DORX_REL=${ORX_MINOR}
            /DORX_MOD=${ORX_MOD_LVL}
            /DORX_BLD=${ORX_BLD_LVL}
            /DORX_VER_STR=${ORX_VER_STR}
            /DOOREXX_COPY_YEAR="${ORX_COPY_YEAR}"
            /DORX_SYS_STR="${ORX_SYS_STR}"
            /DORX_SHARED_LIBRARY_EXT="${CMAKE_SHARED_LIBRARY_SUFFIX}"
            /DORX_SYSTEM_PROCESSOR="${NSIS_CPU}"
            /DORX_REXXPATH="${CMAKE_REXXPATH}"
            # we build for Vista or higher; no more XP support
            # (this define restricts us to the Win 6.0 APIs; anything higher will fail)
            /D_WIN32_WINNT=0x0600
            # suppress CRT_SECURE warnings
            # (we might instead use the secure versions, by using these two DEFINEs:
#           /D_CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES=1
#           /D_CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_COUNT=1
            /D_CRT_SECURE_NO_DEPRECATE
            /D_CRT_SECURE_NO_WARNINGS
            /D_CRT_NONSTDC_NO_DEPRECATE
            /DNOMINMAX
            # suppress warning C4291: no matching operator delete found; memory will not be freed if initialization throws an exception
            /wd4291
# give errors for missing override specifications or method hiding with warning level 3
#           /w34263 /w34266
            /DWIN32 /D_WINDOWS /DHAVE_CONFIG_H)
else ()
   add_definitions(-DORX_VER=${ORX_MAJOR} -DORX_REL=${ORX_MINOR} -DORX_MOD=${ORX_MOD_LVL} -DORX_BLD=${ORX_BLD_LVL}
            -DOOREXX_COPY_YEAR="${ORX_COPY_YEAR}"
            -DORX_SYS_STR="${ORX_SYS_STR}"
            -D_GNU_SOURCE
            -DORX_SHARED_LIBRARY_EXT="${CMAKE_SHARED_LIBRARY_SUFFIX}"
            -DORX_SYSTEM_PROCESSOR="${CMAKE_SYSTEM_PROCESSOR}"
            -DORX_REXXPATH="${CMAKE_REXXPATH}"
            -D${ORX_SYS_STR} -DOPSYS_${ORX_SYS_STR} -DHAVE_CONFIG_H)
endif ()

# Check header files and functions. These are all defined to the config.h file.
message(STATUS "-- determine available header files --")
check_include_file(malloc.h   HAVE_MALLOC_H)
check_include_file(stdint.h   HAVE_STDINT_H)
check_include_file(xlocale.h  HAVE_XLOCALE_H)

if (NOT WIN32) # Unix header files, libraries, and functions
  check_include_file(features.h   HAVE_FEATURES_H)
  check_include_file(ifaddrs.h    HAVE_IFADDRS_H)
  check_include_file(nl_types.h   HAVE_NL_TYPES_H)
  check_include_file(pthread_np.h HAVE_PTHREAD_NP_H)
  check_include_file(strings.h    HAVE_STRINGS_H)
  check_include_file(sys/filio.h  HAVE_SYS_FILIO_H)
  check_include_file(sys/ldr.h    HAVE_SYS_LDR_H)
  check_include_file(sys/resource.h HAVE_SYS_RESOURCE_H)
  check_include_file(sys/select.h HAVE_SYS_SELECT_H)
  check_include_file(sys/sem.h    HAVE_SYS_SEM_H)
  check_include_file(sys/signal.h HAVE_SYS_SIGNAL_H)
  check_include_file(sys/xattr.h  HAVE_SYS_XATTR_H)
  check_include_file(wordexp.h    HAVE_WORDEXP_H)
  if (NOT ORX_WASM)
    set (CURSES_NEED_NCURSES TRUE)
    include(FindCurses) # sets CURSES_HAVE_NCURSES_H and CURSES_HAVE_NCURSES_NCURSES_H
    message(STATUS "CURSES_HAVE_NCURSES_H is ${CURSES_HAVE_NCURSES_H}")
    message(STATUS "CURSES_HAVE_NCURSES_NCURSES_H is ${CURSES_HAVE_NCURSES_NCURSES_H}")
  endif ()

  message(STATUS "-- determine available libraries --")
  set(CMAKE_REQUIRED_LIBRARIES ${CMAKE_DL_LIBS})
  check_library_exists(rt nanosleep "" HAVE_LIBRT)
  if (HAVE_LIBRT)
    list(APPEND CMAKE_REQUIRED_LIBRARIES rt)
  endif ()
  check_library_exists(pthread pthread_create "" HAVE_LIBPTHREAD)
  if (HAVE_LIBPTHREAD)
    list(APPEND CMAKE_REQUIRED_LIBRARIES pthread)
  endif ()
  check_library_exists(crypt crypt "" HAVE_LIBCRYPT)
  if (HAVE_LIBCRYPT)
    list(APPEND CMAKE_REQUIRED_LIBRARIES crypt)
  endif ()
  # SunOS/Solaris libraries
  check_library_exists(socket getaddrinfo "" HAVE_LIBSOCKET)
  if (HAVE_LIBSOCKET)
    list(APPEND CMAKE_REQUIRED_LIBRARIES socket)
  endif ()
  check_library_exists(nsl gethostbyname "" HAVE_LIBNSL)
  if (HAVE_LIBNSL)
    list(APPEND CMAKE_REQUIRED_LIBRARIES nsl)
  endif ()
  check_library_exists(resolv hstrerror "" HAVE_LIBRESOLV)
  if (HAVE_LIBRESOLV)
    list(APPEND CMAKE_REQUIRED_LIBRARIES resolv)
  endif ()

  message(STATUS "-- determine available functions --")
  # pthread_getattr_np() and dladdr() require _GNU_SOURCE
  list(APPEND CMAKE_REQUIRED_DEFINITIONS -D_GNU_SOURCE)
  check_function_exists(catopen HAVE_CATOPEN)
  check_function_exists(crypt HAVE_CRYPT)
  check_symbol_exists(dladdr dlfcn.h HAVE_DLADDR)
  check_function_exists(euidaccess HAVE_EUIDACCESS)
  check_symbol_exists(getifaddrs "sys/types.h;sys/socket.h;ifaddrs.h" HAVE_GETIFADDRS)
  check_function_exists(nanosleep HAVE_NANOSLEEP)
  check_function_exists(nsleep HAVE_NSLEEP)
  check_function_exists(pthread_mutex_timedlock HAVE_PTHREAD_MUTEX_TIMEDLOCK)
  check_symbol_exists(pthread_getattr_np pthread.h HAVE_PTHREAD_GETATTR_NP)
  if (HAVE_PTHREAD_NP_H)
    check_symbol_exists(pthread_attr_get_np "pthread.h;pthread_np.h" HAVE_PTHREAD_ATTR_GET_NP)
  else ()
    check_symbol_exists(pthread_attr_get_np pthread.h HAVE_PTHREAD_ATTR_GET_NP)
  endif ()
  check_symbol_exists(pthread_stackseg_np pthread_np.h HAVE_PTHREAD_STACKSEG_NP)
  check_symbol_exists(pthread_get_stacksize_np pthread.h HAVE_PTHREAD_GET_STACKSIZE_NP)
  check_symbol_exists(wordexp "wordexp.h;stdlib.h" HAVE_WORDEXP)
  check_symbol_exists(_PC_CASE_SENSITIVE unistd.h HAVE_PC_CASE_SENSITIVE)
  check_symbol_exists(FNM_CASEFOLD fnmatch.h HAVE_FNM_CASEFOLD)
  check_symbol_exists(KDMKTONE linux/kd.h HAVE_KDMKTONE)
  check_symbol_exists(FS_CASEFOLD_FL linux/fs.h HAVE_FS_CASEFOLD_FL)
  check_symbol_exists(_NSGetExecutablePath mach-o/dyld.h HAVE_NSGETEXECUTABLEPATH)
  check_symbol_exists(getexecname stdlib.h HAVE_GETEXECNAME)
  check_symbol_exists(KERN_PROC_PATHNAME "sys/types.h;sys/sysctl.h" HAVE_KERN_PROC_PATHNAME)
  check_symbol_exists(KERN_PROC_ARGV "sys/types.h;sys/sysctl.h" HAVE_KERN_PROC_ARGV)
  check_struct_has_member("struct stat" st_mtim sys/stat.h HAVE_STAT_ST_MTIM)
  check_struct_has_member("struct stat" st_mtimespec sys/stat.h HAVE_STAT_ST_MTIMESPEC)

  message(STATUS "-- determine available pragmas --")
  check_c_source_compiles("void main() {
    #pragma GCC diagnostic ignored \"-Wstringop-overflow\"
    }" HAVE_PRAGMA_GCC_STRINGOPOVERFLOW FAIL_REGEX "warning")

endif ()

# Configure files config.h
configure_file(config.h.in.cmake ${PROJECT_BINARY_DIR}/config.h)


#/*----------------------------------------------------------------------------*/
#/* Subdirectory short names                                                   */
#/*----------------------------------------------------------------------------*/
set (build_common_dir common)
set (build_common_platform_dir ${build_common_dir}/${ORX_PLATFORM_DIR})
set (build_lib_dir lib)
set (build_platform_dir ${ORX_PLATFORM_DIR})
set (build_rexxapi_dir rexxapi)
set (build_rexxapi_client_dir ${build_rexxapi_dir}/client)
set (build_rexxapi_client_platform_dir ${build_rexxapi_client_dir}/${ORX_PLATFORM_DIR})
set (build_rexxapi_common_dir ${build_rexxapi_dir}/common)
set (build_rexxapi_common_platform_dir ${build_rexxapi_common_dir}/${ORX_PLATFORM_DIR})
set (build_rexxapi_server_dir ${build_rexxapi_dir}/server)
set (build_rexxapi_server_platform_dir ${build_rexxapi_server_dir}/${ORX_PLATFORM_DIR})
set (build_interpreter_dir interpreter)
set (build_interpreter_platform_dir ${build_interpreter_dir}/${ORX_PLATFORM_DIR})
set (build_interpreter_api_dir ${build_interpreter_dir}/api)
set (build_behaviour_dir ${build_interpreter_dir}/behaviour)
set (build_classes_dir ${build_interpreter_dir}/classes)
set (build_classes_support_dir ${build_interpreter_dir}/classes/support)
set (build_concurrency_dir ${build_interpreter_dir}/concurrency)
set (build_execution_dir ${build_interpreter_dir}/execution)
set (build_expression_dir ${build_interpreter_dir}/expression)
set (build_instructions_dir ${build_interpreter_dir}/instructions)
set (build_memory_dir ${build_interpreter_dir}/memory)
set (build_messages_dir ${build_interpreter_dir}/messages)
set (build_package_dir ${build_interpreter_dir}/package)
set (build_parser_dir ${build_interpreter_dir}/parser)
set (build_interpreter_common_dir ${build_interpreter_dir}/platform/common)
set (build_rexx_classes_dir ${build_interpreter_dir}/RexxClasses)
set (build_runtime_dir ${build_interpreter_dir}/runtime)
set (build_streamlibrary_dir ${build_interpreter_dir}/streamLibrary)
set (build_extensions_dir extensions)
set (build_extensions_platform_dir ${build_extensions_dir}/${ORX_PLATFORM_DIR})
set (build_extensions_rxftp_dir ${build_extensions_dir}/rxftp)
set (build_extensions_csvstream_dir ${build_extensions_dir}/csvStream)
set (build_extensions_logicalwrapper_dir ${build_extensions_dir}/logicalwrapper)
set (build_extensions_json_dir ${build_extensions_dir}/json)
set (build_extensions_yaml_dir ${build_extensions_dir}/yaml)
set (build_extensions_dateparser_dir ${build_extensions_dir}/dateparser)
set (build_extensions_rxmath_dir ${build_extensions_dir}/rxmath)
set (build_extensions_rxregexp_dir ${build_extensions_dir}/rxregexp)
set (build_extensions_rxsock_dir ${build_extensions_dir}/rxsock)
set (build_extensions_orxncurses_dir ${build_extensions_dir}/orxncurses)
set (build_extensions_hostemu_dir ${build_extensions_dir}/hostemu)
set (build_extensions_hostemu_platform_dir ${build_extensions_hostemu_dir}/${ORX_PLATFORM_DIR})
set (build_utilities_dir utilities)
set (build_utilities_rexx_dir ${build_utilities_dir}/rexx/${ORX_PLATFORM_DIR})
set (build_utilities_rexxc_dir ${build_utilities_dir}/rexxc/${ORX_PLATFORM_DIR})
set (build_utilities_rexximage_dir ${build_utilities_dir}/rexximage)
set (build_utilities_rxqueue_dir ${build_utilities_dir}/rxqueue/${ORX_PLATFORM_DIR})
set (build_utilities_rxsubcom_dir ${build_utilities_dir}/rxsubcom/${ORX_PLATFORM_DIR})
set (build_api_dir api)
set (build_api_platform_dir api/${ORX_PLATFORM_DIR})
set (build_samples_dir samples)
set (api_dir ${build_api_dir}/${ORX_PLATFORM_DIR})

set(SAMPLES_SOURCE ${CMAKE_CURRENT_SOURCE_DIR}/${build_samples_dir})

if (WIN32)
   set (platform_samples_dir ${build_samples_dir}/windows)
else ()
   set (platform_samples_dir ${build_samples_dir}/unix)
endif ()

# The following are windows only
set (build_extensions_ole_dir ${build_extensions_dir}/platform/windows/ole)
set (build_extensions_oodialog_dir ${build_extensions_dir}/platform/windows/oodialog)
set (build_extensions_rxwinsys_dir ${build_extensions_dir}/platform/windows/rxwinsys)
set (build_utilities_rexxpaws_dir ${build_utilities_dir}/platform/windows/rexxpaws)
set (build_utilities_rexxhide_dir ${build_utilities_dir}/platform/windows/rexxhide)

if (WIN32)
# change exception handling flag for [bugs:#1728] Hang condition
string(REGEX REPLACE "/EHsc" "/EHsc-" CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS}")

# This replaces the /MD compile flag with /MT.
# as soon as we can require CMake minimum of 3.15 below hack should be replaced with
# set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
set(CompilerFlags
        CMAKE_CXX_FLAGS
        CMAKE_CXX_FLAGS_DEBUG
        CMAKE_CXX_FLAGS_RELEASE
        CMAKE_CXX_FLAGS_RELWITHDEBINFO
        CMAKE_C_FLAGS
        CMAKE_C_FLAGS_DEBUG
        CMAKE_C_FLAGS_RELEASE
        CMAKE_C_FLAGS_RELWITHDEBINFO
        )
foreach(CompilerFlag ${CompilerFlags})
  string(REPLACE "/MD" "/MT" ${CompilerFlag} "${${CompilerFlag}}")
endforeach()
endif ()

#/*----------------------------------------------------------------------------*/
#/* Build targets                                                              */
#/*----------------------------------------------------------------------------*/

# macro to create and install symbolic links on Unix
macro(create_install_symlink target)
   if (UNIX)   # checking for UNIX here simplifies invocation of this macro (no need to check operating system for the invoker)
      set(baseName   "${CMAKE_SHARED_LIBRARY_PREFIX}${target}")
      set(targetName "${baseName}${CMAKE_SHARED_LIBRARY_SUFFIX}")

      foreach(loop_var RANGE ${SYM_LINK_CREATE_FROM} ${SYM_LINK_CREATE_TO})
         if (APPLE)   # Darwin has version numbers before ".dylib"
            set(linkName "${baseName}.${loop_var}${CMAKE_SHARED_LIBRARY_SUFFIX}")
         else ()
            set(linkName "${baseName}${CMAKE_SHARED_LIBRARY_SUFFIX}.${loop_var}")
         endif ()

         # message(STATUS "---> macro create_install_symlink() ${CMAKE_LIBRARY_OUTPUT_DIRECTORY}: ln -sf targetName=[${targetName}] linkName=[${linkName}]")

         add_custom_command(
             TARGET ${target}
             POST_BUILD
             COMMAND ${CMAKE_COMMAND} -E chdir ${CMAKE_LIBRARY_OUTPUT_DIRECTORY} ln -sf ${targetName} ${linkName}
             # COMMENT "--> ${CMAKE_LIBRARY_OUTPUT_DIRECTORY}: [ln -sf ${targetName} ${linkName} DEPENDS ${target}]"
         )

         install(FILES ${CMAKE_LIBRARY_OUTPUT_DIRECTORY}/${linkName}
                 COMPONENT Core
                 DESTINATION ${INSTALL_LIB_DIR}
         )
      endforeach(loop_var)
   endif ()
endmacro(create_install_symlink)


#################### librexxapi.so ##########################
# Full set of files used in all platforms.
set (common_rexxapi_sources
            ${build_rexxapi_client_dir}/ClientMessage.cpp
            ${build_rexxapi_client_dir}/LocalAPIContext.cpp
            ${build_rexxapi_client_dir}/LocalAPIManager.cpp
            ${build_rexxapi_client_dir}/LocalMacroSpaceManager.cpp
            ${build_rexxapi_client_dir}/LocalQueueManager.cpp
            ${build_rexxapi_client_dir}/LocalRegistrationManager.cpp
            ${build_rexxapi_client_dir}/MacroSpaceApi.cpp
            ${build_rexxapi_client_dir}/QueuesAPI.cpp
            ${build_rexxapi_client_dir}/RegistrationAPI.cpp
            ${build_rexxapi_client_platform_dir}/SysLegacyAPI.cpp
            ${build_rexxapi_client_platform_dir}/SysLocalAPIManager.cpp
            ${build_rexxapi_common_dir}/RegistrationTable.cpp
            ${build_rexxapi_common_dir}/ServiceMessage.cpp
            ${build_rexxapi_common_dir}/CSStream.cpp
            ${build_rexxapi_common_platform_dir}/SysAPIManager.cpp
            ${build_common_dir}/Utilities.cpp
            ${build_common_platform_dir}/SysSemaphore.cpp
            ${build_common_platform_dir}/SysLibrary.cpp
            ${build_common_platform_dir}/SysFile.cpp
            ${build_common_platform_dir}/SysProcess.cpp
            ${build_common_platform_dir}/SysThread.cpp)
# additional source files required by specific platforms
if (WIN32)
   set (platform_rexxapi_sources
            ${build_rexxapi_common_platform_dir}/SysCSNamedPipeStream.cpp
            ${build_rexxapi_client_platform_dir}/rexxapi.def
            ${build_platform_dir}/verinfo.rc)
   set (platform_rexxapi_libs wsock32)
else ()
   if (ORX_WASI)
      # the API server shared between processes over the host's connections
      # (SysHostConnection), or reached in-process (SysLoopbackConnection)
      set (platform_rexxapi_sources
            ${build_rexxapi_common_platform_dir}/SysHostConnection.cpp)
   else ()
   set (platform_rexxapi_sources
            ${build_rexxapi_common_platform_dir}/SysCSStream.cpp)
   endif ()
endif ()
# Library definition
if (ORX_WASM)
  # No rxapi daemon in a WASM process: the API server (queues, registrations,
  # macrospace) is linked in and reached through SysLoopbackConnection.
  add_library(rexxapi STATIC
              ${common_rexxapi_sources}
              ${platform_rexxapi_sources}
              ${build_rexxapi_common_platform_dir}/SysLoopbackConnection.cpp
              ${build_rexxapi_server_dir}/APIServer.cpp
              ${build_rexxapi_server_dir}/APIServerInstance.cpp
              ${build_rexxapi_server_dir}/APIServerThread.cpp
              ${build_rexxapi_server_dir}/MacroSpaceManager.cpp
              ${build_rexxapi_server_dir}/QueueManager.cpp
              ${build_rexxapi_server_dir}/RegistrationManager.cpp)
  target_include_directories(rexxapi PRIVATE ${build_rexxapi_server_dir})
else ()
  add_library(rexxapi SHARED
              ${common_rexxapi_sources}
              ${platform_rexxapi_sources})
endif ()
# Include file definition
target_include_directories(rexxapi PUBLIC
            ${build_rexxapi_client_dir}
            ${build_rexxapi_client_platform_dir}
            ${build_rexxapi_common_dir}
            ${build_rexxapi_common_platform_dir}
            ${build_common_dir}
            ${build_common_platform_dir}
            ${build_lib_dir})
# Extra link library definitions
target_link_libraries(rexxapi ${platform_rexxapi_libs} ${CMAKE_REQUIRED_LIBRARIES})

install(TARGETS rexxapi RUNTIME DESTINATION ${INSTALL_LIB_DIR} COMPONENT Core
                        LIBRARY DESTINATION ${INSTALL_LIB_DIR} COMPONENT Core
                        ARCHIVE DESTINATION ${INSTALL_INCLUDE_DIR} COMPONENT DevLib)
set_target_properties(rexxapi PROPERTIES SOVERSION ${ORX_API_LEVEL})
create_install_symlink(rexxapi)

##################### utf8proc ###########################

if (WIN32)
    # To avoid warning LNK4217
    add_definitions(/DUTF8PROC_STATIC)
endif ()


#################### librexx.so ##########################
# Sources for librexx.so
set (interpreter_api_sources ${build_interpreter_api_dir}/CallContextStubs.cpp
            ${build_interpreter_api_dir}/InterpreterAPI.cpp
            ${build_interpreter_api_dir}/InterpreterInstanceStubs.cpp
            ${build_interpreter_api_dir}/MethodContextStubs.cpp
            ${build_interpreter_api_dir}/ThreadContextStubs.cpp)
set (classes_support_sources ${build_classes_support_dir}/HashCollection.cpp
            ${build_classes_support_dir}/HashContents.cpp
            ${build_classes_support_dir}/ListContents.cpp
            ${build_classes_support_dir}/ProgramMetaData.cpp
            ${build_classes_support_dir}/CompoundTableElement.cpp
            ${build_classes_support_dir}/CompoundVariableTable.cpp
            ${build_classes_support_dir}/CompoundVariableTail.cpp
            ${build_classes_support_dir}/RexxDateTime.cpp
            ${build_classes_support_dir}/StringUtil.cpp
            ${build_classes_support_dir}/Unicode/utf8proc/utf8proc.c)
set (classes_sources ${build_classes_dir}/ArrayClass.cpp
            ${build_classes_dir}/BagClass.cpp
            ${build_classes_dir}/BufferClass.cpp
            ${build_classes_dir}/ClassClass.cpp
            ${build_classes_dir}/ContextClass.cpp
            ${build_classes_dir}/DirectoryClass.cpp
            ${build_classes_dir}/EventSemaphore.cpp
            ${build_classes_dir}/IntegerClass.cpp
            ${build_classes_dir}/ListClass.cpp
            ${build_classes_dir}/MessageClass.cpp
            ${build_classes_dir}/MethodClass.cpp
            ${build_classes_dir}/MutableBufferClass.cpp
            ${build_classes_dir}/MutexSemaphore.cpp
            ${build_classes_dir}/NumberStringClass.cpp
            ${build_classes_dir}/NumberStringMath.cpp
            ${build_classes_dir}/NumberStringMath2.cpp
            ${build_classes_dir}/ObjectClass.cpp
            ${build_classes_dir}/PackageClass.cpp
            ${build_classes_dir}/PointerClass.cpp
            ${build_classes_dir}/QueueClass.cpp
            ${build_classes_dir}/RelationClass.cpp
            ${build_classes_dir}/RexxInfoClass.cpp
            ${build_classes_dir}/RoutineClass.cpp
            ${build_classes_dir}/RexxQueueMethods.cpp
            ${build_classes_dir}/SetClass.cpp
            ${build_classes_dir}/StemClass.cpp
            ${build_classes_dir}/StringClass.cpp
            ${build_classes_dir}/StringClassBit.cpp
            ${build_classes_dir}/StringClassConversion.cpp
            ${build_classes_dir}/StringClassMisc.cpp
            ${build_classes_dir}/StringClassSub.cpp
            ${build_classes_dir}/StringClassUtil.cpp
            ${build_classes_dir}/StringClassWord.cpp
            ${build_classes_dir}/StringTableClass.cpp
            ${build_classes_dir}/SupplierClass.cpp
            ${build_classes_dir}/TableClass.cpp
            ${build_classes_dir}/IdentityTableClass.cpp
            ${build_classes_dir}/WeakReferenceClass.cpp
            ${build_classes_dir}/StackFrameClass.cpp
            ${build_classes_dir}/VariableReference.cpp)
set (package_sources ${build_package_dir}/LibraryPackage.cpp
            ${build_package_dir}/PackageManager.cpp)
set (memory_sources ${build_memory_dir}/DeadObject.cpp
            ${build_memory_dir}/FileNameBuffer.cpp
            ${build_memory_dir}/GlobalNames.cpp
            ${build_memory_dir}/MapBucket.cpp
            ${build_memory_dir}/MapTable.cpp
            ${build_memory_dir}/MemorySegment.cpp
            ${build_memory_dir}/MemoryStack.cpp
            ${build_memory_dir}/MemoryStats.cpp
            ${build_memory_dir}/NumberArray.cpp
            ${build_memory_dir}/PointerBucket.cpp
            ${build_memory_dir}/PointerTable.cpp
            ${build_memory_dir}/ProtectedObject.cpp
            ${build_memory_dir}/Envelope.cpp
            ${build_memory_dir}/InternalStack.cpp
            ${build_memory_dir}/SmartBuffer.cpp
            ${build_memory_dir}/UninitDispatcher.cpp
            ${build_memory_dir}/Setup.cpp
            ${build_memory_dir}/RexxMemory.cpp)
set (execution_sources ${build_execution_dir}/CPPCode.cpp
            ${build_execution_dir}/ActivationStack.cpp
            ${build_execution_dir}/ActivationSettings.cpp
            ${build_execution_dir}/RexxActivation.cpp
            ${build_execution_dir}/BaseCode.cpp
            ${build_execution_dir}/RexxCode.cpp
            ${build_execution_dir}/BaseExecutable.cpp
            ${build_execution_dir}/RexxLocalVariables.cpp
            ${build_execution_dir}/NativeActivation.cpp
            ${build_execution_dir}/NativeCode.cpp
            ${build_execution_dir}/RexxVariable.cpp
            ${build_execution_dir}/TrapHandler.cpp
            ${build_execution_dir}/VariableDictionary.cpp
            ${build_execution_dir}/SecurityManager.cpp
            ${build_execution_dir}/TraceSetting.cpp)
set (behaviour_sources ${build_behaviour_dir}/PrimitiveBehaviours.cpp
            ${build_behaviour_dir}/RexxBehaviour.cpp
            ${build_behaviour_dir}/MethodDictionary.cpp
            ${build_behaviour_dir}/VirtualFunctionTable.cpp)
set (concurrency_sources ${build_concurrency_dir}/ActivityDispatcher.cpp
            ${build_concurrency_dir}/ActivityManager.cpp
            ${build_concurrency_dir}/ActivationFrame.cpp
            ${build_concurrency_dir}/CallbackDispatcher.cpp
            ${build_concurrency_dir}/TrappingDispatcher.cpp
            ${build_concurrency_dir}/ConditionTrappingDispatcher.cpp
            ${build_concurrency_dir}/ExitHandler.cpp
            ${build_concurrency_dir}/CommandHandler.cpp
            ${build_concurrency_dir}/MessageDispatcher.cpp
            ${build_concurrency_dir}/Activity.cpp
            ${build_concurrency_dir}/RexxStartDispatcher.cpp
            ${build_concurrency_dir}/TranslateDispatcher.cpp)
set (expression_sources ${build_expression_dir}/BuiltinFunctions.cpp
            ${build_expression_dir}/CommonExternalFunctions.cpp
            ${build_expression_dir}/ExpressionClassResolver.cpp
            ${build_expression_dir}/ExpressionCompoundVariable.cpp
            ${build_expression_dir}/ExpressionDotVariable.cpp
            ${build_expression_dir}/SpecialDotVariable.cpp
            ${build_expression_dir}/ExpressionFunction.cpp
            ${build_expression_dir}/ExpressionMessage.cpp
            ${build_expression_dir}/ExpressionOperator.cpp
            ${build_expression_dir}/ExpressionQualifiedFunction.cpp
            ${build_expression_dir}/ExpressionStack.cpp
            ${build_expression_dir}/ExpressionStem.cpp
            ${build_expression_dir}/ExpressionVariable.cpp
            ${build_expression_dir}/IndirectVariableReference.cpp
            ${build_expression_dir}/ExpressionList.cpp
            ${build_expression_dir}/ExpressionLogical.cpp
            ${build_expression_dir}/VariableReferenceOp.cpp)
set (instructions_sources  ${build_instructions_dir}/AddressInstruction.cpp
            ${build_instructions_dir}/AddressWithInstruction.cpp
            ${build_instructions_dir}/AssignmentInstruction.cpp
            ${build_instructions_dir}/AddressInstruction.cpp
            ${build_instructions_dir}/BaseDoInstruction.cpp
            ${build_instructions_dir}/CallInstruction.cpp
            ${build_instructions_dir}/ClassDirective.cpp
            ${build_instructions_dir}/CommandInstruction.cpp
            ${build_instructions_dir}/CommandIOContext.cpp
            ${build_instructions_dir}/CommandIOConfiguration.cpp
            ${build_instructions_dir}/ConstantDirective.cpp
            ${build_instructions_dir}/InputRedirector.cpp
            ${build_instructions_dir}/OutputRedirector.cpp
            ${build_instructions_dir}/DoBlock.cpp
            ${build_instructions_dir}/DoBlockComponents.cpp
            ${build_instructions_dir}/DoCountInstruction.cpp
            ${build_instructions_dir}/SimpleDoInstruction.cpp
            ${build_instructions_dir}/ControlledDoInstruction.cpp
            ${build_instructions_dir}/DoForeverInstruction.cpp
            ${build_instructions_dir}/DoOverInstruction.cpp
            ${build_instructions_dir}/DoWithInstruction.cpp
            ${build_instructions_dir}/DoWhileInstruction.cpp
            ${build_instructions_dir}/DropInstruction.cpp
            ${build_instructions_dir}/ElseInstruction.cpp
            ${build_instructions_dir}/EndIf.cpp
            ${build_instructions_dir}/EndInstruction.cpp
            ${build_instructions_dir}/ExitInstruction.cpp
            ${build_instructions_dir}/ExposeInstruction.cpp
            ${build_instructions_dir}/ForwardInstruction.cpp
            ${build_instructions_dir}/GuardInstruction.cpp
            ${build_instructions_dir}/IfInstruction.cpp
            ${build_instructions_dir}/InterpretInstruction.cpp
            ${build_instructions_dir}/LabelInstruction.cpp
            ${build_instructions_dir}/LeaveInstruction.cpp
            ${build_instructions_dir}/LibraryDirective.cpp
            ${build_instructions_dir}/MessageInstruction.cpp
            ${build_instructions_dir}/NopInstruction.cpp
            ${build_instructions_dir}/NumericInstruction.cpp
            ${build_instructions_dir}/OptionsInstruction.cpp
            ${build_instructions_dir}/OtherwiseInstruction.cpp
            ${build_instructions_dir}/CatchInstruction.cpp
            ${build_instructions_dir}/FinallyInstruction.cpp
            ${build_instructions_dir}/ParseInstruction.cpp
            ${build_instructions_dir}/ParseTarget.cpp
            ${build_instructions_dir}/ParseTrigger.cpp
            ${build_instructions_dir}/ProcedureInstruction.cpp
            ${build_instructions_dir}/QueueInstruction.cpp
            ${build_instructions_dir}/RaiseInstruction.cpp
            ${build_instructions_dir}/ReplyInstruction.cpp
            ${build_instructions_dir}/RequiresDirective.cpp
            ${build_instructions_dir}/ReturnInstruction.cpp
            ${build_instructions_dir}/RexxInstruction.cpp
            ${build_instructions_dir}/SayInstruction.cpp
            ${build_instructions_dir}/SelectInstruction.cpp
            ${build_instructions_dir}/SignalInstruction.cpp
            ${build_instructions_dir}/ThenInstruction.cpp
            ${build_instructions_dir}/TraceInstruction.cpp
            ${build_instructions_dir}/UseInstruction.cpp
            ${build_instructions_dir}/UseArgVariableRef.cpp
            ${build_instructions_dir}/UseLocalInstruction.cpp
            ${build_instructions_dir}/WhenCaseInstruction.cpp)
set (parser_sources ${build_parser_dir}/Clause.cpp
            ${build_parser_dir}/KeywordConstants.cpp
            ${build_parser_dir}/DirectiveParser.cpp
            ${build_parser_dir}/InstructionParser.cpp
            ${build_parser_dir}/LanguageParser.cpp
            ${build_parser_dir}/ProgramSource.cpp
            ${build_parser_dir}/Scanner.cpp
            ${build_parser_dir}/Token.cpp)
set (platform_sources ${build_interpreter_platform_dir}/ExternalFunctions.cpp
            ${build_interpreter_platform_dir}/MemorySupport.cpp
            ${build_interpreter_platform_dir}/MiscSystem.cpp
            ${build_interpreter_platform_dir}/SysActivity.cpp
            ${build_interpreter_platform_dir}/SysFileSystem.cpp
            ${build_interpreter_platform_dir}/SysInterpreterInstance.cpp
            ${build_interpreter_platform_dir}/SysRexxUtil.cpp
            ${build_interpreter_platform_dir}/SystemCommands.cpp
            ${build_interpreter_platform_dir}/SystemInitialization.cpp
            ${build_interpreter_platform_dir}/SystemInterpreter.cpp
            ${build_interpreter_platform_dir}/TimeSupport.cpp
            ${build_interpreter_platform_dir}/UseridFunction.cpp
            ${build_interpreter_platform_dir}/ValueFunction.cpp)
set (common_sources ${build_common_dir}/Utilities.cpp
            ${build_common_platform_dir}/SysFile.cpp
            ${build_common_platform_dir}/SysLibrary.cpp
            ${build_common_platform_dir}/SysProcess.cpp
            ${build_common_platform_dir}/SysSemaphore.cpp
            ${build_common_platform_dir}/SysThread.cpp)
set (runtime_sources ${build_runtime_dir}/InternalPackage.cpp
            ${build_runtime_dir}/Interpreter.cpp
            ${build_runtime_dir}/InterpreterInstance.cpp
            ${build_runtime_dir}/Numerics.cpp
            ${build_runtime_dir}/RexxUtilCommon.cpp
            ${build_runtime_dir}/Version.cpp)
set (streamlibrary_sources ${build_streamlibrary_dir}/StreamCommandParser.cpp
            ${build_streamlibrary_dir}/StreamNative.cpp
            ${build_streamlibrary_dir}/FileNative.cpp)

# Full set of files used in all platforms.
set (common_interpreter_sources ${classes_sources}
            ${classes_support_sources}
            ${interpreter_api_sources}
            ${behaviour_sources}
            ${execution_sources}
            ${memory_sources}
            ${package_sources}
            ${concurrency_sources}
            ${expression_sources}
            ${instructions_sources}
            ${parser_sources}
            ${platform_sources}
            ${common_sources}
            ${runtime_sources}
            ${streamlibrary_sources})

# additional source files required by specific platforms
if (WIN32)
   set (platform_interpreter_sources ${build_interpreter_platform_dir}/rexx.def
                                     ${build_platform_dir}/verinfo.rc)
   set (platform_interpreter_libs comctl32 shlwapi version)
else ()
   set (platform_interpreter_sources ${build_interpreter_platform_dir}/RexxMain.cpp)
endif ()

# Library definition
if (ORX_WASM)
  # WASM builds statically embed the native extension packages (see
  # PackageManager::embeddedPackages): there is no dlopen.  The ones that need
  # nothing from the system beyond files; Emscripten also has sockets and
  # the Unix system calls of rxunixsys.
  set (wasm_embedded_package_sources
              ${build_extensions_rxregexp_dir}/automaton.cpp
              ${build_extensions_rxregexp_dir}/dblqueue.cpp
              ${build_extensions_rxregexp_dir}/rxregexp.cpp
              ${build_extensions_rxmath_dir}/rxmath.cpp
              ${build_extensions_hostemu_platform_dir}/hostemu.cpp
              ${build_extensions_hostemu_dir}/cmdparse.cpp)
  if (EMSCRIPTEN)
    list (APPEND wasm_embedded_package_sources
              ${build_extensions_rxsock_dir}/rxsock.cpp
              ${build_extensions_rxsock_dir}/rxsockfn.cpp
              ${build_extensions_platform_dir}/rxunixsys/rxunixsys.cpp)
  elseif (CMAKE_SYSTEM_NAME STREQUAL "WASI")
    # WASI: rxunixsys too, its calls over the host where it has them
    # (stat, chmod...), the rest failing as unsupported; and rxsock, its
    # socket calls redirected to the host's sockets (orx_wasi_net.h, on the
    # include path of the build's flags)
    list (APPEND wasm_embedded_package_sources
              ${build_extensions_rxsock_dir}/rxsock.cpp
              ${build_extensions_rxsock_dir}/rxsockfn.cpp
              ${build_extensions_platform_dir}/rxunixsys/rxunixsys.cpp)
    set_source_files_properties(${build_extensions_rxsock_dir}/rxsock.cpp
              ${build_extensions_rxsock_dir}/rxsockfn.cpp
              PROPERTIES COMPILE_OPTIONS "-include;orx_wasi_net.h")
  endif ()
  set_source_files_properties(${wasm_embedded_package_sources}
              PROPERTIES COMPILE_DEFINITIONS OOREXX_EMBEDDED_PACKAGE)
  add_library(rexx STATIC
              ${common_interpreter_sources}
              ${platform_interpreter_sources}
              ${wasm_embedded_package_sources})
  target_include_directories(rexx PRIVATE ${build_extensions_hostemu_dir})
else ()
  add_library(rexx SHARED
              ${common_interpreter_sources}
              ${platform_interpreter_sources})
endif ()

set (core_platform_classes ${build_interpreter_platform_dir}/PlatformObjects.orx)
# Include file definition
target_include_directories(rexx PUBLIC
            ${build_lib_dir}
            ${build_api_dir}
            ${build_api_platform_dir}
            ${build_common_dir}
            ${build_common_platform_dir}
            ${build_interpreter_dir}
            ${build_behaviour_dir}
            ${build_execution_dir}
            ${build_memory_dir}
            ${build_package_dir}
            ${build_concurrency_dir}
            ${build_expression_dir}
            ${build_instructions_dir}
            ${build_classes_dir}
            ${build_classes_support_dir}
            ${build_runtime_dir}
            ${build_parser_dir}
            ${build_messages_dir}
            ${build_streamlibrary_dir}
            ${build_interpreter_common_dir}
            ${build_interpreter_platform_dir})

# Extra link library definitions
target_link_libraries(rexx rexxapi ${platform_interpreter_libs} ${CMAKE_REQUIRED_LIBRARIES})
if (CMAKE_INTERPROCEDURAL_OPTIMIZATION)
    if (CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
        if (CMAKE_VERSION VERSION_LESS "3.13")
            message(STATUS "CMake 3.13 or later is required for target_link_options")
            message(STATUS "Not disabling lto-wrapper warning: writing 1 byte into a region of size 0")
        else ()
            target_link_options (rexx PRIVATE -Wno-stringop-overflow)
        endif ()
    endif ()
endif ()
install(TARGETS rexx RUNTIME DESTINATION ${INSTALL_LIB_DIR} COMPONENT Core
                     LIBRARY DESTINATION ${INSTALL_LIB_DIR} COMPONENT Core
                     ARCHIVE DESTINATION ${INSTALL_INCLUDE_DIR} COMPONENT DevLib)
set_target_properties(rexx PROPERTIES SOVERSION ${ORX_API_LEVEL})
create_install_symlink(rexx)

#################### orexx (executable) ##########################
if (WIN32)
   set (platform_rexx_exe_sources ${build_platform_dir}/rexx.rc)
endif ()
# Sources for rexx.  Note, the target must not be rexx, since we already
# have a rexx library target
add_executable(rexx_exe ${build_utilities_rexx_dir}/rexx.cpp
                        ${platform_rexx_exe_sources})
if (ORX_WASM)
  # rexxc, rxqueue and rxsubcom are part of the WASM rexx executable
  # (multi-call, see wasm/rexxc-main.cpp)
  target_sources(rexx_exe PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/wasm/rexxc-main.cpp
                                  ${CMAKE_CURRENT_SOURCE_DIR}/wasm/rxqueue-main.cpp
                                  ${CMAKE_CURRENT_SOURCE_DIR}/wasm/rxsubcom-main.cpp)
  target_include_directories(rexx_exe PRIVATE ${build_interpreter_platform_dir})
endif ()
# This allows the executable to have the same name as the library.
SET_TARGET_PROPERTIES(rexx_exe
  PROPERTIES OUTPUT_NAME rexx)

if (WIN32)
# We need to override the PDB output file name for rexx.exe so it doesn't overwrite
# the file for rexx.dll, which essentially makes the interpreter undebuggable on Windows
# we want to append, which is a little bit of a pain.
   get_property(link_flags TARGET rexx_exe PROPERTY LINK_FLAGS_DEBUG)
   set(link_flags "${link_flags} /PDB:bin\\orexx.pdb")
   set_target_properties(rexx_exe PROPERTIES LINK_FLAGS_DEBUG ${link_flags})

   get_property(link_flags TARGET rexx_exe PROPERTY LINK_FLAGS_RELWITHDEBINFO)
   set(link_flags "${link_flags} /PDB:bin\\orexx.pdb")
   set_target_properties(rexx_exe PROPERTIES LINK_FLAGS_RELWITHDEBINFO ${link_flags})
endif ()

# Include file definition
target_include_directories(rexx_exe PUBLIC
            ${build_lib_dir}
            ${build_api_dir}
            ${build_api_platform_dir}
            ${build_messages_dir})
# Extra link library definitions
if (ORX_WASM)
  # librexx is a static archive in the WASM build.  Nothing references
  # SystemInitialization.cpp, so without --whole-archive the linker drops it
  # together with the _rexx_init() constructor that creates the kernel and
  # resource locks; every SysMutex then stays uncreated, request() returns
  # false without locking, and the interpreter runs threads unsynchronized.
  if (ORX_WASI)
    # CMake has no WHOLE_ARCHIVE feature for the WASI platform
    target_link_libraries(rexx_exe -Wl,--whole-archive rexx -Wl,--no-whole-archive rexxapi ${CMAKE_REQUIRED_LIBRARIES})
  else ()
    target_link_libraries(rexx_exe "$<LINK_LIBRARY:WHOLE_ARCHIVE,rexx>" rexxapi ${CMAKE_REQUIRED_LIBRARIES})
  endif ()
else ()
  target_link_libraries(rexx_exe rexx rexxapi ${CMAKE_REQUIRED_LIBRARIES})
endif ()
# Merge in extra manifestinformation on Windows
if (WIN32)
add_custom_command(TARGET rexx_exe POST_BUILD
   # DEPENDS ${EXE_MANIFEST_FILE}
   COMMAND "mt.exe" -nologo -manifest \"${EXE_MANIFEST_FILE}\" "-inputresource:bin\\rexx.exe;#1" "-outputresource:bin\\rexx.exe;#1"
   COMMENT "Adding custom manifest to rexx.exe...")
endif ()

install(TARGETS rexx_exe RUNTIME COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})

#################### rexximage (bin file) ##########################
# These are the core classes built into the .img file.
set (core_classes ${build_rexx_classes_dir}/CoreClasses.orx
            ${build_rexx_classes_dir}/StreamClasses.orx
            ${build_rexx_classes_dir}/CommandClasses.orx)
# additional source files required by specific platforms
if (WIN32)
   set (platform_rexximage_sources ${build_platform_dir}/verinfo.rc)
endif ()
# Sources for rexximg
add_executable(rexximage ${build_utilities_rexximage_dir}/rexximage.cpp
            ${core_classes}
            ${platform_rexximage_sources})
# Include file definition
target_include_directories(rexximage PUBLIC
            ${build_lib_dir}
            ${build_api_dir}
            ${build_api_platform_dir})
# Extra link library definitions
if (ORX_WASM)
  # see rexx_exe: keep the _rexx_init() constructor
  if (ORX_WASI)
    # CMake has no WHOLE_ARCHIVE feature for the WASI platform
    target_link_libraries(rexximage -Wl,--whole-archive rexx -Wl,--no-whole-archive rexxapi ${CMAKE_REQUIRED_LIBRARIES})
  else ()
    target_link_libraries(rexximage "$<LINK_LIBRARY:WHOLE_ARCHIVE,rexx>" rexxapi ${CMAKE_REQUIRED_LIBRARIES})
  endif ()
else ()
  target_link_libraries(rexximage rexx rexxapi ${CMAKE_REQUIRED_LIBRARIES})
endif ()

# handy macro for copying files from the source into the build directory.
macro (copy_build_file name source)
    ADD_CUSTOM_COMMAND(
       OUTPUT ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/${name}
       COMMAND ${CMAKE_COMMAND} -E copy_if_different ${CMAKE_CURRENT_SOURCE_DIR}/${source}/${name} ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/${name}
       DEPENDS ${source}/${name}
       )
endmacro (copy_build_file)

# handy macro for copying files from the source into the build samples directory.
macro (copy_samples_file name source)
    ADD_CUSTOM_COMMAND(
       OUTPUT ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/${name}
       COMMAND ${CMAKE_COMMAND} -E copy_if_different ${CMAKE_CURRENT_SOURCE_DIR}/${source}/${name} ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/${name}
       DEPENDS ${source}/${name}
       )
endmacro (copy_samples_file)

# handy macro for configuring files from the source into the build directory.
macro (configure_build_file name source)
    configure_file(${CMAKE_CURRENT_SOURCE_DIR}/${source}/${name} ${CMAKE_CURRENT_BINARY_DIR}/${source}/${name} @ONLY)
endmacro (configure_build_file)


# Copy the class files to the build directory
copy_build_file(CoreClasses.orx ${build_rexx_classes_dir})
copy_build_file(StreamClasses.orx ${build_rexx_classes_dir})
copy_build_file(CommandClasses.orx ${build_rexx_classes_dir})
copy_build_file(PlatformObjects.orx ${build_interpreter_platform_dir})

# These are the portable class files the image requires
set (image_class_files
   ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/CoreClasses.orx
   ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/StreamClasses.orx
   ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/CommandClasses.orx
   ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/PlatformObjects.orx)

# On Windows, the ole support is also included in the image
if (WIN32)
  copy_build_file(orexxole.cls ${build_extensions_ole_dir})
  set (platform_rexx_img_depends orexxole
       ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/orexxole.cls)
endif ()

# Build the rexx.img file
if (ORX_WASM)
  add_custom_command(OUTPUT ${ORX_IMAGE_OUTPUT_LOCATION}/rexx.img
             COMMAND ${CMAKE_CROSSCOMPILING_EMULATOR} $<TARGET_FILE:rexximage> ${ORX_IMAGE_OUTPUT_LOCATION}/rexx.img
             DEPENDS rexximage ${image_class_files} ${platform_rexx_img_depends}
             WORKING_DIRECTORY ${CMAKE_RUNTIME_OUTPUT_DIRECTORY})
else ()
  add_custom_command(OUTPUT ${ORX_IMAGE_OUTPUT_LOCATION}/rexx.img
             COMMAND $<TARGET_FILE:rexximage> ${ORX_IMAGE_OUTPUT_LOCATION}/rexx.img
             DEPENDS rexximage rxapi ${image_class_files} ${platform_rexx_img_depends}
             WORKING_DIRECTORY ${CMAKE_RUNTIME_OUTPUT_DIRECTORY})
endif ()

add_custom_target(rexx_img ALL DEPENDS ${ORX_IMAGE_OUTPUT_LOCATION}/rexx.img)
install(PROGRAMS ${ORX_IMAGE_OUTPUT_LOCATION}/rexx.img COMPONENT Core DESTINATION ${INSTALL_LIB_DIR} PERMISSIONS OWNER_EXECUTE GROUP_EXECUTE WORLD_EXECUTE OWNER_WRITE OWNER_READ GROUP_READ WORLD_READ)

#################### rxapi (executable) #########################
# additional source files required by specific platforms
if (WIN32)
   set (platform_rxapi_sources
            ${build_rexxapi_server_platform_dir}/APIService.cpp
            ${build_rexxapi_common_platform_dir}/SysCSNamedPipeStream.cpp
            ${build_rexxapi_server_platform_dir}/rxapi.rc
            ${build_rexxapi_server_platform_dir}/rxapi.ico)
   set (rxapi_executable_type WIN32)
   set (platform_rxapi_libs wsock32 shlwapi)
else ()
   set (platform_rxapi_sources
            ${build_rexxapi_common_platform_dir}/SysCSStream.cpp
            ${build_rexxapi_server_platform_dir}/APIService.cpp)
endif ()
# Sources for rxapi
add_executable(rxapi ${rxapi_executable_type}
         ${build_rexxapi_server_dir}/APIServer.cpp
         ${build_rexxapi_server_dir}/APIServerInstance.cpp
         ${build_rexxapi_server_dir}/APIServerThread.cpp
         ${build_rexxapi_server_dir}/MacroSpaceManager.cpp
         ${build_rexxapi_server_dir}/QueueManager.cpp
         ${build_rexxapi_server_dir}/RegistrationManager.cpp
         ${build_rexxapi_common_dir}/CSStream.cpp
         ${build_rexxapi_common_dir}/RegistrationTable.cpp
         ${build_rexxapi_common_dir}/ServiceMessage.cpp
         ${build_rexxapi_common_platform_dir}/SysAPIManager.cpp
         ${build_common_dir}/Utilities.cpp
         ${build_common_platform_dir}/SysProcess.cpp
         ${build_common_platform_dir}/SysSemaphore.cpp
         ${build_common_platform_dir}/SysThread.cpp
         ${platform_rxapi_sources})
# Include file definition
target_include_directories(rxapi PUBLIC
         ${build_rexxapi_server_dir})
# Extra link library definitions
target_link_libraries(rxapi rexx rexxapi ${platform_rxapi_libs} ${CMAKE_REQUIRED_LIBRARIES})

# Kill the rxapi daemon whenever we have to build, otherwise the build
# will fail.  Unfortunately, the killing of the process is not immediate,
# so we attach this as a dependency to multiple early pieces of the project
# to give it a chance to free up the file.
if (WIN32)
   add_custom_target(kill_rexxapi
        ${CMAKE_SOURCE_DIR}/${ORX_PLATFORM_DIR}/killapi.bat
        COMMENT "Killing rxapi daemon...")
   # add this as a dependency for major bits to give it a chance to
   # execute early.
   add_dependencies(rexx kill_rexxapi)
   add_dependencies(rexxapi kill_rexxapi)
   add_dependencies(rxapi kill_rexxapi)
endif ()
install(TARGETS rxapi RUNTIME COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})

#################### message_headers #########################
# Autogenerate the message header files and the primitive classes files, but
# only if the xalan executable is available.
if (XALAN_EXECUTABLE)

    # handy macro for generating a file from the rexxmsg.xml file
    macro (generate_message_file target xsl)
        ADD_CUSTOM_COMMAND(
           OUTPUT ${CMAKE_CURRENT_SOURCE_DIR}/${target}
           COMMAND ${XALAN_EXECUTABLE} -o ${CMAKE_CURRENT_SOURCE_DIR}/${target} ${build_messages_dir}/rexxmsg.xml ${xsl}
           DEPENDS ${build_messages_dir}/rexxmsg.xml ${xsl}
           COMMENT "Generating ${CMAKE_CURRENT_SOURCE_DIR}/${target}"
           WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}
           )
    endmacro (generate_message_file)

    # handy macro for generating a file from the PrimitiveClasses.xml file
    macro (generate_class_header target xsl)
        ADD_CUSTOM_COMMAND(
           OUTPUT ${CMAKE_CURRENT_SOURCE_DIR}/${build_behaviour_dir}/${target}
           COMMAND ${XALAN_EXECUTABLE} -o ${build_behaviour_dir}/${target} ${build_behaviour_dir}/PrimitiveClasses.xml ${build_behaviour_dir}/${xsl}
           DEPENDS ${build_behaviour_dir}/PrimitiveClasses.xml ${build_behaviour_dir}/${xsl}
           COMMENT "Generating ${CMAKE_CURRENT_SOURCE_DIR}/${build_behaviour_dir}/${target}"
           WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}
           )
    endmacro (generate_class_header)

    generate_message_file(${build_messages_dir}/RexxErrorCodes.h ${build_messages_dir}/RexxErrorCodes.xsl)
    generate_message_file(${build_messages_dir}/RexxMessageNumbers.h ${build_messages_dir}/RexxMessageNumbers.xsl)
    generate_message_file(${build_messages_dir}/RexxMessageTable.h ${build_messages_dir}/RexxMessageTable.xsl)
    generate_message_file(${build_messages_dir}/RexxErrorMessages.h ${build_messages_dir}/RexxErrorMessages.xsl)
    generate_message_file(${build_api_dir}/oorexxerrors.h ${build_messages_dir}/ApiErrorCodes.xsl)
    generate_message_file(${build_messages_dir}/errnums.xml ${build_messages_dir}/errnums.xsl)
    generate_message_file(${build_messages_dir}/errnumsrxqueue.xml ${build_messages_dir}/errnumsrxqueue.xsl)
    generate_message_file(${build_messages_dir}/errnumssubcom.xml ${build_messages_dir}/errnumssubcom.xsl)
    generate_message_file(${build_messages_dir}/errnumsrexxc.xml ${build_messages_dir}/errnumsrexxc.xsl)

    generate_class_header(PrimitiveBehaviourNames.h PrimitiveBehaviourNames.xsl)
    generate_class_header(PrimitiveBehaviours.cpp PrimitiveBehaviours.xsl)
    generate_class_header(VirtualFunctionTable.cpp VirtualFunctionTable.xsl)
    generate_class_header(ClassTypeCodes.h ClassTypeCodes.xsl)

    set (REXXMSG_FILES ${build_messages_dir}/RexxErrorCodes.h
                       ${build_messages_dir}/RexxMessageNumbers.h
                       ${build_messages_dir}/RexxErrorMessages.h
                       ${build_messages_dir}/RexxMessageTable.h
                       ${build_api_dir}/oorexxerrors.h
                       ${build_messages_dir}/errnums.xml
                       ${build_messages_dir}/errnumsrxqueue.xml
                       ${build_messages_dir}/errnumssubcom.xml
                       ${build_messages_dir}/errnumsrexxc.xml
                       ${build_behaviour_dir}/PrimitiveBehaviourNames.h
                       ${build_behaviour_dir}/PrimitiveBehaviours.cpp
                       ${build_behaviour_dir}/VirtualFunctionTable.cpp
                       ${build_behaviour_dir}/ClassTypeCodes.h)

    add_custom_target(message_headers ALL DEPENDS ${REXXMSG_FILES})

    # add dependencies to the main build pieces
    add_dependencies(rexx message_headers)
    add_dependencies(rexxapi message_headers)

endif ()


#################### rexxc (executable) #########################
# additional source files required by specific platforms
if (WIN32)
   set (platform_rexxc_sources ${build_platform_dir}/verinfo.rc)
endif ()
# Sources for rexxc
add_executable(rexxc ${build_utilities_rexxc_dir}/RexxCompiler.cpp
                     ${platform_rexxc_sources})
# Include file definition
target_include_directories(rexxc PUBLIC
            ${build_lib_dir}
            ${build_api_dir}
            ${build_api_platform_dir}
            ${build_messages_dir})
# Extra link library definitions
target_link_libraries(rexxc rexx rexxapi ${CMAKE_REQUIRED_LIBRARIES})
install(TARGETS rexxc RUNTIME COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})

#################### rxqueue (executable) #########################
# additional source files required by specific platforms
if (WIN32)
   set (platform_rxqueue_sources ${build_platform_dir}/verinfo.rc)
endif ()
# Sources for rxqueue
add_executable(rxqueue ${build_utilities_rxqueue_dir}/rxqueue.cpp
                     ${platform_rxqueue_sources})
# Include file definition
target_include_directories(rxqueue PUBLIC
            ${build_lib_dir}
            ${build_api_dir}
            ${build_api_platform_dir}
            ${build_interpreter_platform_dir}
            ${build_messages_dir})
# Extra link library definitions
target_link_libraries(rxqueue rexx rexxapi ${CMAKE_REQUIRED_LIBRARIES})
install(TARGETS rxqueue RUNTIME COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})

#################### rxsubcom (executable) #########################
# additional source files required by specific platforms
if (WIN32)
   set (platform_subcom_sources ${build_platform_dir}/verinfo.rc)
endif ()
# Sources for rxsubcom
add_executable(rxsubcom ${build_utilities_rxsubcom_dir}/rxsubcom.cpp
                     ${platform_subcom_sources})
# Include file definition
target_include_directories(rxsubcom PUBLIC
             ${build_lib_dir}
             ${build_api_dir}
             ${build_api_platform_dir}
             ${build_interpreter_platform_dir}
             ${build_messages_dir})
# Extra link library definitions
target_link_libraries(rxsubcom rexx rexxapi ${CMAKE_REQUIRED_LIBRARIES})
install(TARGETS rxsubcom RUNTIME COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})

#################### librxmath.so ################
# additional source files required by specific platforms
if (WIN32)
   set (platform_rxmath_sources ${build_platform_dir}/verinfo.rc)
endif ()
# Sources for librxmath.so
add_library(rxmath SHARED ${build_extensions_rxmath_dir}/rxmath.cpp
                          ${platform_rxmath_sources})

# Include file definition
target_include_directories(rxmath PUBLIC
             ${build_lib_dir}
             ${build_api_dir}
             ${build_api_platform_dir})
# Extra link library definitions
target_link_libraries(rxmath rexx rexxapi ${CMAKE_REQUIRED_LIBRARIES})
install(TARGETS rxmath RUNTIME COMPONENT Core DESTINATION ${INSTALL_LIB_DIR}
                       LIBRARY DESTINATION ${INSTALL_LIB_DIR} COMPONENT Core)
set_target_properties(rxmath PROPERTIES SOVERSION ${ORX_API_LEVEL})
create_install_symlink(rxmath)

#################### librxsock.so ################
# WASM embeds RxSock into librexx (Emscripten) or has no sockets (WASI);
# native platforms keep the shared package.
if (NOT ORX_WASM)
# additional source files required by specific platforms
if (WIN32)
   set (platform_rxsock_sources ${build_platform_dir}/verinfo.rc)
endif ()

# Sources for librxsock.so
add_library(rxsock SHARED ${build_extensions_rxsock_dir}/rxsock.cpp
             ${build_extensions_rxsock_dir}/rxsockfn.cpp
             ${platform_rxsock_sources})
# Extra link library definitions
target_link_libraries(rxsock rexx rexxapi ${CMAKE_REQUIRED_LIBRARIES})
install(TARGETS rxsock RUNTIME COMPONENT Core DESTINATION ${INSTALL_LIB_DIR}
                       LIBRARY DESTINATION ${INSTALL_LIB_DIR} COMPONENT Core)
set_target_properties(rxsock PROPERTIES SOVERSION ${ORX_API_LEVEL})
create_install_symlink(rxsock)
endif ()


#################### librxregexp.so ################
# additional source files required by specific platforms
if (WIN32)
   set (platform_rxregexp_sources ${build_platform_dir}/verinfo.rc)
endif ()

# Sources for librxregexp.so
add_library(rxregexp SHARED ${build_extensions_rxregexp_dir}/automaton.cpp
             ${build_extensions_rxregexp_dir}/dblqueue.cpp
             ${build_extensions_rxregexp_dir}/rxregexp.cpp
             ${platform_rxregexp_sources})
# Include file definition
target_include_directories(rxregexp PUBLIC
             ${build_lib_dir}
             ${build_api_dir}
             ${build_api_platform_dir}
             ${build_messages_dir})
# Extra link library definitions
target_link_libraries(rxregexp rexx rexxapi ${CMAKE_REQUIRED_LIBRARIES})
install(TARGETS rxregexp RUNTIME COMPONENT Core DESTINATION ${INSTALL_LIB_DIR}
                         LIBRARY DESTINATION ${INSTALL_LIB_DIR} COMPONENT Core)
set_target_properties(rxregexp PROPERTIES SOVERSION ${ORX_API_LEVEL})
create_install_symlink(rxregexp)

#################### libhostemu.so ################
# additional source files required by specific platforms
if (WIN32)
   set (platform_hostemu_sources ${build_platform_dir}/verinfo.rc)
endif ()
# Sources for libhostemu.so
# Note that we ignore the dependency on hostemu.ypp for now.
add_library(hostemu SHARED ${build_extensions_hostemu_platform_dir}/hostemu.cpp
             ${build_extensions_hostemu_dir}/cmdparse.cpp
             ${platform_hostemu_sources})
# Include file definition
target_include_directories(hostemu PUBLIC
             ${build_api_dir}
             ${build_api_platform_dir}
             ${build_extensions_hostemu_dir})
# Extra link library definitions
target_link_libraries(hostemu rexx rexxapi ${CMAKE_REQUIRED_LIBRARIES})
install(TARGETS hostemu RUNTIME COMPONENT Core DESTINATION ${INSTALL_LIB_DIR}
                        LIBRARY DESTINATION ${INSTALL_LIB_DIR} COMPONENT Core)
set_target_properties(hostemu PROPERTIES SOVERSION ${ORX_API_LEVEL})
create_install_symlink(hostemu)

#################### librxunixsys.so ################
if (NOT WIN32)
# Sources for librxunixsys.so
add_library(rxunixsys SHARED ${build_extensions_platform_dir}/rxunixsys/rxunixsys.cpp)
# Include file definition
target_include_directories(rxunixsys PUBLIC
             ${build_api_dir}
             ${build_api_platform_dir}
             ${extensions_unix_dir}/rxunixsys)
# Extra link library definitions
target_link_libraries(rxunixsys rexx rexxapi ${CMAKE_REQUIRED_LIBRARIES})
set_target_properties(rxunixsys PROPERTIES SOVERSION ${ORX_API_LEVEL})
install(TARGETS rxunixsys RUNTIME DESTINATION ${INSTALL_LIB_DIR}
                          LIBRARY DESTINATION ${INSTALL_LIB_DIR} COMPONENT Core)
   create_install_symlink(rxunixsys)
endif ()

#################### liborxncurses.so ################
if (NOT WIN32 AND NOT ORX_WASM)
   # need to copy this to the binary dir
   copy_build_file(ncurses.cls ${build_extensions_orxncurses_dir})
   # Sources for liborxncurses.so
   add_library(orxncurses SHARED ${build_extensions_dir}/orxncurses/orxncurses.cpp)
   # Include file definition
   target_include_directories(orxncurses PUBLIC
             ${build_api_dir}
             ${build_api_platform_dir}
             ${build_extensions_dir}/orxncurses
             ${CURSES_INCLUDE_DIRS})
   # Extra link library definitions
   target_link_libraries(orxncurses rexx rexxapi ${CURSES_LIBRARIES} ${CMAKE_REQUIRED_LIBRARIES})
   # Make sure ncurses.cls gets copied
   add_custom_target(ncurses_cls  ALL DEPENDS ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/ncurses.cls)
   set_target_properties(orxncurses PROPERTIES SOVERSION ${ORX_API_LEVEL})
   install(TARGETS orxncurses RUNTIME DESTINATION ${INSTALL_LIB_DIR}
                          LIBRARY DESTINATION ${INSTALL_LIB_DIR} COMPONENT Core)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/ncurses.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
   create_install_symlink(orxncurses)
endif ()

#################### orexxole.dll ################
if (WIN32)
# Sources for orexxole.dll
add_library(orexxole SHARED ${build_extensions_ole_dir}/orexxole.cpp
             ${build_extensions_ole_dir}/OLEVariant.cpp
             ${build_extensions_ole_dir}/events.cpp
             ${build_extensions_ole_dir}/orexxole.def
             ${build_platform_dir}/verinfo.rc)
# Include file definition
target_include_directories(orexxole PUBLIC
             ${build_extensions_ole_dir})
# Extra link library definitions
target_link_libraries(orexxole rexx rexxapi ${CMAKE_REQUIRED_LIBRARIES})
install(TARGETS orexxole RUNTIME COMPONENT Core DESTINATION ${INSTALL_LIB_DIR})
endif ()

#################### rxwinsys.dll ################
if (WIN32)
   # need to copy this to the binary dir
   copy_build_file(winsystm.cls ${build_extensions_rxwinsys_dir})
   # Sources for rxwinwys.dll
   add_library(rxwinsys SHARED ${build_extensions_rxwinsys_dir}/rxwinsys.cpp
                ${build_platform_dir}/verinfo.rc)
   # Include file definition
   target_include_directories(rxwinsys PUBLIC
                ${build_extensions_rxwinsys_dir})
   # Extra link library definitions
   target_link_libraries(rxwinsys rexx rexxapi shlwapi)
   # Make sure winsystm.cls gets copied
   add_custom_target(winsystm_cls ALL DEPENDS ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/winsystm.cls)
   #add_dependencies(rxwinsys ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/winsystm.cls)
   install(TARGETS rxwinsys RUNTIME COMPONENT Core DESTINATION ${INSTALL_LIB_DIR})
   install(PROGRAMS ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/winsystm.cls COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})
endif ()

#################### oodialog ################
if (WIN32)
   set (OOD_MAJOR 4)
   set (OOD_MINOR 2)
   set (OOD_MOD_LVL 5)
   set (OOD_BLD_LVL 12940)
   set (OOD_VER_STR "4.2.5.12940")
   set (OOD_COPY_YEAR "2005-2025")

   #################### ooshapes.dll ################
   # Sources for ooshapes.dll
   add_library(ooshapes SHARED
                ${build_extensions_oodialog_dir}/APICommon.cpp
                ${build_extensions_oodialog_dir}/ooShapes.cpp
                ${build_extensions_oodialog_dir}/ooShapesAid.cpp
                ${build_extensions_oodialog_dir}/ooShapesPE.cpp)
   # Override the compile definitions with ooShapes-exclusive defines
   set_property(TARGET ooshapes
          PROPERTY COMPILE_DEFINITIONS
          OOSHAPES_VER_MAJOR=${OOD_MAJOR}
          OOSHAPES_VER_MINOR=${OOD_MINOR}
          OOSHAPES_VER_LEVEL=${OOD_MOD_LVL}
          OOSHAPES_VER_BUILD=${OOD_BLD_LVL}
          OOSHAPES_COPYRIGHT_YEAR=${OOD_COPY_YEAR})

   # Include file definition
   target_include_directories(ooshapes PUBLIC
                ${build_extensions_oodialog_dir})
   # Extra link library definitions
   target_link_libraries(rexx rexxapi)
   install(TARGETS ooshapes RUNTIME COMPONENT Core DESTINATION ${INSTALL_LIB_DIR})

   # Copy ooShapes.cls to the build directory
   copy_build_file(ooShapes.cls ${build_extensions_oodialog_dir})
   install(PROGRAMS ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/ooShapes.cls COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})
   add_custom_target(ooshapes_cls ALL DEPENDS ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/ooShapes.cls)


   #################### oodialog.dll ################
   # Sources for oodialog.dll
   add_library(oodialog SHARED
                ${build_extensions_oodialog_dir}/APICommon.cpp
                ${build_extensions_oodialog_dir}/oodBarControls.cpp
                ${build_extensions_oodialog_dir}/oodBaseDialog.cpp
                ${build_extensions_oodialog_dir}/oodBasicControls.cpp
                ${build_extensions_oodialog_dir}/oodCommon.cpp
                ${build_extensions_oodialog_dir}/oodControl.cpp
                ${build_extensions_oodialog_dir}/oodData.cpp
                ${build_extensions_oodialog_dir}/oodDeviceGraphics.cpp
                ${build_extensions_oodialog_dir}/ooDialog.cpp
                ${build_extensions_oodialog_dir}/oodKeyboard.cpp
                ${build_extensions_oodialog_dir}/oodListView.cpp
                ${build_extensions_oodialog_dir}/oodMenu.cpp
                ${build_extensions_oodialog_dir}/oodMessaging.cpp
                ${build_extensions_oodialog_dir}/oodMouse.cpp
                ${build_extensions_oodialog_dir}/oodPackageEntry.cpp
                ${build_extensions_oodialog_dir}/oodPropertySheetDialog.cpp
                ${build_extensions_oodialog_dir}/oodReBar.cpp
                ${build_extensions_oodialog_dir}/oodResizableDialog.cpp
                ${build_extensions_oodialog_dir}/oodResources.cpp
                ${build_extensions_oodialog_dir}/oodRoutines.cpp
                ${build_extensions_oodialog_dir}/oodShared.cpp
                ${build_extensions_oodialog_dir}/oodShellObjects.cpp
                ${build_extensions_oodialog_dir}/oodStatusBar.cpp
                ${build_extensions_oodialog_dir}/oodToolBar.cpp
                ${build_extensions_oodialog_dir}/oodToolTip.cpp
                ${build_extensions_oodialog_dir}/oodTreeView.cpp
                ${build_extensions_oodialog_dir}/oodUser.cpp
                ${build_extensions_oodialog_dir}/oodUtilities.cpp
                ${build_extensions_oodialog_dir}/oodViewControls.cpp
#               ${build_extensions_oodialog_dir}/ooShapes.cpp
#               ${build_extensions_oodialog_dir}/ooShapesAid.cpp
                ${build_extensions_oodialog_dir}/ooDialog.rc)
   # Override the compile definitions with ooDialog-exclusive defines
   set_property(TARGET oodialog
          PROPERTY COMPILE_DEFINITIONS
          OOD_VER=${OOD_MAJOR}
          OOD_REL=${OOD_MINOR}
          OOD_MOD=${OOD_MOD_LVL}
          OOD_BLD=${OOD_BLD_LVL}
          OOD_COPY_YEAR=${OOD_COPY_YEAR}
          OOSHAPES_VER_MAJOR=${OOD_MAJOR}
          OOSHAPES_VER_MINOR=${OOD_MINOR}
          OOSHAPES_VER_LEVEL=${OOD_MOD_LVL}
          OOSHAPES_VER_BUILD=${OOD_BLD_LVL}
          OOSHAPES_COPYRIGHT_YEAR=${OOD_COPY_YEAR}
          OOD_VER_STR="ooDialog ${OOD_MAJOR}.${OOD_MINOR}.${OOD_MOD_LVL}.${OOD_BLD_LVL}"
          OOD_BIN_NAME="oodialog.dll")

   # Include file definition
   target_include_directories(oodialog PUBLIC
                ${build_extensions_oodialog_dir})
   # Extra link library definitions
   target_link_libraries(oodialog ooshapes rexx rexxapi winmm comdlg32 comctl32 shlwapi oleacc uxtheme rpcrt4 propsys delayimp)
   install(TARGETS oodialog RUNTIME COMPONENT Core DESTINATION ${INSTALL_LIB_DIR})

   #################### ooDialog.exe (executable) ##########################
   # Sources for ooDialog.exe
   add_executable(oodialog_exe WIN32 ${build_extensions_oodialog_dir}/oodWinMain.cpp
                                     ${build_extensions_oodialog_dir}/oodShared.cpp
                                     ${build_extensions_oodialog_dir}/ooDialogWinMain.rc)
   add_dependencies(oodialog_exe oodialog)
# We need to override the PDB output file name for oodialog.exe so it doesn't overwrite
# the file for oodialog.dll, which essentially makes oodialog undebuggable on Windows
# we want to append, which is a little bit of a pain.
   get_property(link_flags TARGET oodialog_exe PROPERTY LINK_FLAGS_DEBUG)
   set(link_flags "${link_flags} /PDB:bin\\ooDialog_exe.pdb")
   set_target_properties(oodialog_exe PROPERTIES LINK_FLAGS_DEBUG ${link_flags})

   get_property(link_flags TARGET oodialog_exe PROPERTY LINK_FLAGS_RELWITHDEBINFO)
   set(link_flags "${link_flags} /PDB:bin\\ooDialog_exe.pdb")
   set_target_properties(oodialog_exe PROPERTIES LINK_FLAGS_RELWITHDEBINFO ${link_flags})

   set_property(TARGET oodialog_exe
          PROPERTY COMPILE_DEFINITIONS
          OOD_VER=${OOD_MAJOR}
          OOD_REL=${OOD_MINOR}
          OOD_MOD=${OOD_MOD_LVL}
          OOD_BLD=${OOD_BLD_LVL}
          OOD_COPY_YEAR=${OOD_COPY_YEAR}
          OOD_VER_STR="ooDialog ${OOD_MAJOR}.${OOD_MINOR}.${OOD_MOD_LVL}.${OOD_BLD_LVL}"
          OOD_BIN_NAME="oodialog.exe")
   # This allows the executable to have the same name as the library.
   SET_TARGET_PROPERTIES(oodialog_exe PROPERTIES OUTPUT_NAME ooDialog)
   # Include file definition
   target_include_directories(oodialog_exe PUBLIC
                ${build_extensions_oodialog_dir})
   target_link_libraries(oodialog_exe rexx rexxapi shlwapi)
   add_custom_command(TARGET oodialog_exe POST_BUILD
      # DEPENDS ${EXE_MANIFEST_FILE}
      COMMAND "mt.exe" -nologo -manifest \"${EXE_MANIFEST_FILE}\" "-inputresource:bin\\ooDialog.exe;#1" "-outputresource:bin\\ooDialog.exe;#1"
      COMMENT "Adding custom manifest to ooDialog.exe...")
   install(TARGETS oodialog_exe RUNTIME COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})

   #################### ooDialog.com (executable) ##########################
   # Sources for ooDialog.com
   add_executable(oodialog_com ${build_extensions_oodialog_dir}/oodMain.cpp
                               ${build_extensions_oodialog_dir}/oodShared.cpp
                               ${build_extensions_oodialog_dir}/ooDialogMain.rc)
   add_dependencies(oodialog_com oodialog_exe)
# We need to override the PDB output file name for oodialog.com so it doesn't overwrite
# the file for oodialog.dll, which essentially makes oodialog undebuggable on Windows
# we want to append, which is a little bit of a pain.
   get_property(link_flags TARGET oodialog_com PROPERTY LINK_FLAGS_DEBUG)
   set(link_flags "${link_flags} /PDB:bin\\ooDialog_com.pdb")
   set_target_properties(oodialog_com PROPERTIES LINK_FLAGS_DEBUG ${link_flags})

   get_property(link_flags TARGET oodialog_com PROPERTY LINK_FLAGS_RELWITHDEBINFO)
   set(link_flags "${link_flags} /PDB:bin\\ooDialog_com.pdb")
   set_target_properties(oodialog_com PROPERTIES LINK_FLAGS_RELWITHDEBINFO ${link_flags})

   set_property(TARGET oodialog_com
          PROPERTY COMPILE_DEFINITIONS
          OOD_VER=${OOD_MAJOR}
          OOD_REL=${OOD_MINOR}
          OOD_MOD=${OOD_MOD_LVL}
          OOD_BLD=${OOD_BLD_LVL}
          OOD_COPY_YEAR=${OOD_COPY_YEAR}
          OOD_VER_STR="ooDialog ${OOD_MAJOR}.${OOD_MINOR}.${OOD_MOD_LVL}.${OOD_BLD_LVL}"
          OOD_BIN_NAME="oodialog.com")
   # This allows the executable to have the same name as the library.
   SET_TARGET_PROPERTIES(oodialog_com PROPERTIES OUTPUT_NAME ooDialog)
   SET_TARGET_PROPERTIES(oodialog_com PROPERTIES SUFFIX .com)
   # Include file definition
   target_include_directories(oodialog_com PUBLIC
                ${build_extensions_oodialog_dir})
   target_link_libraries(oodialog_com rexx rexxapi shell32 Advapi32)
   add_custom_command(TARGET oodialog_com POST_BUILD
      # DEPENDS ${EXE_MANIFEST_FILE}
      COMMAND "mt.exe" -nologo -manifest \"${EXE_MANIFEST_FILE}\" "-inputresource:bin\\ooDialog.com;#1" "-outputresource:bin\\ooDialog.com;#1"
      COMMENT "Adding custom manifest to ooDialog.com...")
   install(TARGETS oodialog_com RUNTIME COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})


   # Generate the oodialog .cls files used for the ::requires.  These are generated from
   # from a set of individual source files
   set (oodialog_source_classFiles
      ${build_extensions_oodialog_dir}/UtilityClasses.cls
      ${build_extensions_oodialog_dir}/AnimatedButton.cls
      ${build_extensions_oodialog_dir}/BaseDialog.cls
      ${build_extensions_oodialog_dir}/ControlDialog.cls
      ${build_extensions_oodialog_dir}/DialogControls.cls
      ${build_extensions_oodialog_dir}/ListView.cls
      ${build_extensions_oodialog_dir}/ReBar.cls
      ${build_extensions_oodialog_dir}/StatusBar.cls
      ${build_extensions_oodialog_dir}/ToolBar.cls
      ${build_extensions_oodialog_dir}/ToolTip.cls
      ${build_extensions_oodialog_dir}/TreeView.cls
      ${build_extensions_oodialog_dir}/DialogExtensions.cls
      ${build_extensions_oodialog_dir}/DynamicDialog.cls
      ${build_extensions_oodialog_dir}/EventNotification.cls
      ${build_extensions_oodialog_dir}/PlainBaseDialog.cls
      ${build_extensions_oodialog_dir}/RcDialog.cls
      ${build_extensions_oodialog_dir}/Menu.cls
      ${build_extensions_oodialog_dir}/ResDialog.cls
      ${build_extensions_oodialog_dir}/UserDialog.cls
      ${build_extensions_oodialog_dir}/DeprecatedClasses.cls
      ${build_extensions_oodialog_dir}/ShellObjects.cls)


   # We run a rexx program to generate these files, so we need to have the interpreter
   # fully built first.  The files are generated into the output directory.
   add_custom_command(OUTPUT ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/oodPlain.cls ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/oodWin32.cls ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/ooDialog.cls
              COMMAND $<TARGET_FILE:rexx_exe> build_ooDialog_cls.rex ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}
              DEPENDS rexx_exe rexx_img ${build_extensions_oodialog_dir}/build_ooDialog_cls.rex ${oodialog_source_classfiles}
              WORKING_DIRECTORY ${CMAKE_SOURCE_DIR}/${build_extensions_oodialog_dir})
   add_custom_target(oodialog_cls ALL DEPENDS ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/oodPlain.cls ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/oodWin32.cls ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/ooDialog.cls)

   install(PROGRAMS ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/oodPlain.cls COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})
   install(PROGRAMS ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/oodWin32.cls COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})
   install(PROGRAMS ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/ooDialog.cls COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})
endif ()


#################### rexxhide (executable) ##########################
if (WIN32)
   # Sources for rexxhide.
   add_executable(rexxhide WIN32 ${build_utilities_rexxhide_dir}/rexxhide.cpp
                           ${build_platform_dir}/verinfo.rc)
   # Include file definition
   target_include_directories(rexxhide PUBLIC
               ${build_lib_dir}
               ${build_api_dir}
               ${build_api_platform_dir}
               ${build_messages_dir})
   target_link_libraries(rexxhide rexx rexxapi)
   add_custom_command(TARGET rexxhide POST_BUILD
      # DEPENDS ${EXE_MANIFEST_FILE}
      COMMAND "mt.exe" -nologo -manifest \"${EXE_MANIFEST_FILE}\" "-inputresource:bin\\rexxhide.exe;#1" "-outputresource:bin\\rexxhide.exe;#1"
      COMMENT "Adding custom manifest to rexxhide.exe...")
   install(TARGETS rexxhide RUNTIME COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})
endif ()


#################### rexxpaws (executable) ##########################
if (WIN32)
   # Sources for rexxpaws.
   add_executable(rexxpaws ${build_utilities_rexxpaws_dir}/rexxpaws.cpp
                           ${build_platform_dir}/verinfo.rc)
   # Include file definition
   target_include_directories(rexxhide PUBLIC
               ${build_lib_dir}
               ${build_api_dir}
               ${build_api_platform_dir}
               ${build_messages_dir})
   target_link_libraries(rexxpaws rexx rexxapi)
   add_custom_command(TARGET rexxpaws POST_BUILD
      # DEPENDS ${EXE_MANIFEST_FILE}
      COMMAND "mt.exe" -nologo -manifest \"${EXE_MANIFEST_FILE}\" "-inputresource:bin\\rexxpaws.exe;#1" "-outputresource:bin\\rexxpaws.exe;#1"
      COMMENT "Adding custom manifest to rexxpaws.exe...")
   install(TARGETS rexxpaws RUNTIME COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})
endif ()


#################### misc files ##########################

# These artifacts apply to all platforms
# We copy the .cls class files to the build directory so that the build has a
# full working copy of the class files for testing/development purposes
copy_build_file(rxregexp.cls     ${build_extensions_rxregexp_dir})
copy_build_file(rxftp.cls        ${build_extensions_rxftp_dir})
copy_build_file(csvStream.cls    ${build_extensions_csvstream_dir})
copy_build_file(logicalwrapper.cls ${build_extensions_logicalwrapper_dir})
copy_build_file(json.cls         ${build_extensions_json_dir})
copy_build_file(json.dtd         ${build_extensions_json_dir})
copy_build_file(json.xsd         ${build_extensions_json_dir})
copy_build_file(xmlToJson.xsl    ${build_extensions_json_dir})
copy_build_file(yaml.cls         ${build_extensions_yaml_dir})
copy_build_file(yaml.dtd         ${build_extensions_yaml_dir})
copy_build_file(yaml.xsd         ${build_extensions_yaml_dir})
copy_build_file(xmlToYaml.xsl    ${build_extensions_yaml_dir})
copy_build_file(dateparser.cls   ${build_extensions_dateparser_dir})
copy_build_file(socket.cls       ${build_extensions_rxsock_dir})
copy_build_file(streamsocket.cls ${build_extensions_rxsock_dir})
copy_build_file(mime.cls         ${build_extensions_rxsock_dir})
copy_build_file(smtp.cls         ${build_extensions_rxsock_dir})
copy_samples_file(cmdhandlers.cls   ${build_samples_dir})
copy_samples_file(complex.cls       ${build_samples_dir})
copy_samples_file(ledit.cls         ${build_samples_dir})
copy_samples_file(pipe.cls          ${build_samples_dir})
copy_samples_file(semcls.cls        ${build_samples_dir})
copy_samples_file(treeDirectory.cls ${build_samples_dir})
copy_samples_file(jabberwocky.txt   ${build_samples_dir})

# the shebang line needs adjusting in the .rex files, so we need to
# do this based on the build target, sorted here alphabetically
configure_build_file(arithmeticEvaluation.rex ${build_samples_dir})
configure_build_file(arrayCallback.rex ${build_samples_dir})
configure_build_file(ccreply.rex ${build_samples_dir})
configure_build_file(concurrency.rex ${build_samples_dir})
configure_build_file(constrained.rex ${build_samples_dir})
configure_build_file(delegation.rex ${build_samples_dir})
configure_build_file(dynamicMethod.rex ${build_samples_dir})
configure_build_file(factor.rex ${build_samples_dir})
configure_build_file(getOoRexxDocs.rex ${build_samples_dir})
configure_build_file(greply.rex ${build_samples_dir})
configure_build_file(guess.rex ${build_samples_dir})
configure_build_file(interface.rex ${build_samples_dir})
configure_build_file(ktguard.rex ${build_samples_dir})
configure_build_file(ledwords.rex ${build_samples_dir})
configure_build_file(makestring.rex ${build_samples_dir})
configure_build_file(month.rex ${build_samples_dir})
configure_build_file(philfork.rex ${build_samples_dir})
configure_build_file(properties.rex ${build_samples_dir})
configure_build_file(qdate.rex ${build_samples_dir})
configure_build_file(qtime.rex ${build_samples_dir})
configure_build_file(rexxtry.rex ${build_samples_dir})
configure_build_file(rexxcps.rex ${build_samples_dir})
configure_build_file(scclient.rex ${build_samples_dir})
configure_build_file(scserver.rex ${build_samples_dir})
configure_build_file(sfclient.rex ${build_samples_dir})
configure_build_file(sfserver.rex ${build_samples_dir})
configure_build_file(singleLinkedList.rex ${build_samples_dir})
configure_build_file(sortComposite.rex ${build_samples_dir})
configure_build_file(stack.rex ${build_samples_dir})
configure_build_file(synchronousConcurrency.rex ${build_samples_dir})
configure_build_file(timezone.rex ${build_samples_dir})
configure_build_file(treeTraversal.rex ${build_samples_dir})
configure_build_file(usecmdhandlers.rex ${build_samples_dir})
configure_build_file(usecomp.rex ${build_samples_dir})
configure_build_file(useledit.rex ${build_samples_dir})
configure_build_file(usepipe.rex ${build_samples_dir})
configure_build_file(usesingleton.rex ${build_samples_dir})
configure_build_file(usetree.rex ${build_samples_dir})

add_custom_target(class_files ALL DEPENDS
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rxregexp.cls
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rxftp.cls
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/csvStream.cls
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/logicalwrapper.cls
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/json.cls
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/json.dtd
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/json.xsd
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/xmlToJson.xsl
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/yaml.cls
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/yaml.dtd
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/yaml.xsd
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/xmlToYaml.xsl
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/socket.cls
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/streamsocket.cls
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/mime.cls
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/smtp.cls
    ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/dateparser.cls
    ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/cmdhandlers.cls
    ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/complex.cls
    ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/ledit.cls
    ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/pipe.cls
    ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/semcls.cls
    ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/treeDirectory.cls
    ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/jabberwocky.txt

    ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/rexxtry.rex)

install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rxregexp.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})

install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rxftp.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})

install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/csvStream.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/logicalwrapper.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/json.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/json.dtd COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/json.xsd COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/xmlToJson.xsl COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/yaml.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/yaml.dtd COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/yaml.xsd COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/xmlToYaml.xsl COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/dateparser.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})

install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/socket.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/streamsocket.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/mime.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/smtp.cls COMPONENT Core DESTINATION ${INSTALL_CLS_DIR})
# technically a sample, but this is so useful we add it to the binary dir
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/rexxtry.rex COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})

install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/${build_api_dir}/rexx.h COMPONENT DevLib DESTINATION ${INSTALL_INCLUDE_DIR})
install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/${build_api_dir}/rexxapidefs.h COMPONENT DevLib DESTINATION ${INSTALL_INCLUDE_DIR})
install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/${build_api_platform_dir}/rexxapitypes.h COMPONENT DevLib DESTINATION ${INSTALL_INCLUDE_DIR})
install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/${build_api_platform_dir}/rexxplatformapis.h COMPONENT DevLib DESTINATION ${INSTALL_INCLUDE_DIR})
install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/${build_api_platform_dir}/rexxplatformdefs.h COMPONENT DevLib DESTINATION ${INSTALL_INCLUDE_DIR})
install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/${build_api_dir}/oorexxapi.h COMPONENT DevLib DESTINATION ${INSTALL_INCLUDE_DIR})
install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/${build_api_dir}/oorexxerrors.h COMPONENT DevLib DESTINATION ${INSTALL_INCLUDE_DIR})

# common sample programs
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/arithmeticEvaluation.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/arrayCallback.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/ccreply.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/concurrency.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/constrained.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/delegation.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/dynamicMethod.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/factor.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/getOoRexxDocs.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/greply.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/guess.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/interface.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/ktguard.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/ledwords.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/makestring.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/month.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/philfork.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/properties.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/qdate.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/qtime.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/scclient.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/scserver.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/sfclient.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/sfserver.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/singleLinkedList.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/sortComposite.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/stack.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/synchronousConcurrency.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/timezone.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/treeTraversal.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/usecmdhandlers.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/usecomp.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/useledit.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/usepipe.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/usesingleton.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/usetree.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})

install(PROGRAMS ${SAMPLES_SOURCE}/cmdhandlers.cls COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${SAMPLES_SOURCE}/complex.cls COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${SAMPLES_SOURCE}/ledit.cls COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${SAMPLES_SOURCE}/pipe.cls COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${SAMPLES_SOURCE}/semcls.cls COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
install(PROGRAMS ${SAMPLES_SOURCE}/treeDirectory.cls COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})


# used in synchronousConcurrency.rex
install(FILES ${SAMPLES_SOURCE}/jabberwocky.txt COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})

# Not strictly a sample but useful
install(PROGRAMS ${CMAKE_SAMPLES_OUTPUT_DIRECTORY}/rexxcps.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})

if (NOT WIN32)
   macro (add_manpage name cat)
      add_custom_command(OUTPUT ${name}.${cat}.gz
              COMMAND gzip -c
              ${CMAKE_CURRENT_SOURCE_DIR}/${build_platform_dir}/${name}.${cat}
              > ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/${name}.${cat}.gz
              DEPENDS ${CMAKE_CURRENT_SOURCE_DIR}/${build_platform_dir}/${name}.${cat})
      add_custom_target(${name}_man ALL DEPENDS ${name}.${cat}.gz)
      install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/${name}.${cat}.gz
          DESTINATION ${INSTALL_MAN_DIR}/man${cat}
          PERMISSIONS OWNER_READ GROUP_READ WORLD_READ OWNER_WRITE)
   endmacro (add_manpage)

   add_manpage (rexx 1)
   add_manpage (rexxc 1)
   add_manpage (rxqueue 1)
   add_manpage (rxsubcom 1)

   install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/${build_samples_dir}/readme.txt DESTINATION ${INSTALL_SAMPLES_DIR})
endif ()


# direct output into a samples subdir
add_subdirectory (samples)

# build the binaries used for API tests.
add_subdirectory (testbinaries)


#################### NSIS Package Targets ##########################
#################### NSIS Package Targets ##########################
#################### NSIS Package Targets ##########################
#################### NSIS Package Targets ##########################
#################### NSIS Package Targets ##########################

# The Windows installer assumes we have the docs available.  Don't try building
# any of the installer stuff if this is not available.
if (DOC_SOURCE_DIR)

 if (WIN32)
   # Add the install directory to the module path so the custom template can be located.
   set(CMAKE_MODULE_PATH ${CMAKE_CURRENT_SOURCE_DIR}/${build_platform_dir}/install ${CMAKE_MODULE_PATH})

   # We do not use the NSIS generator directly, but rather configure our
   # own NSIS installation from a template
   set(CPACK_PACKAGE_INSTALL_DIRECTORY "Open Object Rexx")
   set(CPACK_PACKAGE_INSTALL_REGISTRY_KEY "Open Object Rexx")
   # ask for a modify the pack dialg
   set(CPACK_NSIS_INSTALLED_ICON_NAME "rexx.exe,0")
   set(CPACK_NSIS_URL_INFO_ABOUT "https://www.oorexx.org")
   set(CPACK_NSIS_MUI_ICON ${CMAKE_CURRENT_SOURCE_DIR}/${build_platform_dir}/rexx.ico)
   set(CPACK_NSIS_MUI_UNIICON ${CMAKE_CURRENT_SOURCE_DIR}/${build_platform_dir}/install/uninstall.ico)

   # Not sure why this is not working.  Claims it cannot find the file, but it exists.
   # It might need to be an installed file...not sure
   # set(CPACK_PACKAGE_ICON ${CMAKE_CURRENT_SOURCE_DIR}/${build_platform_dir}/rexx.ico)

   # Component setups
   set(CPACK_COMPONENT_CORE_DISPLAY_NAME "Open Object Rexx Core (required)")
   set(CPACK_COMPONENT_CORE_DESCRIPTION "The Open Object Rexx interpreter and extension libraries.")
   set(CPACK_COMPONENT_CORE_REQUIRED 1)
   set(CPACK_COMPONENT_SAMPLES_DISPLAY_NAME "Open Object Rexx Samples")
   set(CPACK_COMPONENT_SAMPLES_DESCRIPTION "Sample programs that demonstrate Open Object Rexx features.")
   set(CPACK_COMPONENT_DEVLIB_DISPLAY_NAME "Open Object Rexx Development Kit")
   set(CPACK_COMPONENT_DEVLIB_DESCRIPTION "Header files and libraries for using the Open Object Rexx native programming interfaces.")
   set(CPACK_COMPONENT_DOCS_DISPLAY_NAME "Open Object Rexx Documentation")
   set(CPACK_COMPONENT_DOCS_DESCRIPTION "Complete documentation for Open Object Rexx in PDF form.")

   # The Docs are an optional build step, so we only add them if we have
   # been configured with a doc source directory
   set(NSIS_INSTALL_COMPONENTS Core Docs DevLib Samples)


   # Add additional Windows-only install files
   install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/${build_platform_dir}/rexx.ico COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})
   install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/CPLv1.0.txt COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})

   # if this is a Debug or RelWithDebInfo configuration, also install the .pdb files in the binary locations
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/hostemu.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/oodialog.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/oodialog_com.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/oodialog_exe.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/orexx.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/orexxole.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rexx.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rexxapi.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rexxc.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rexxhide.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rexxpaws.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rxapi.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rxmath.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rxqueue.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rxregexp.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rxsock.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rxsubcom.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)
   install(FILES ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rxwinsys.pdb COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR}
       CONFIGURATIONS Debug RelWithDebInfo)

   # technically a sample, but this is so useful we add it to the binary dir
   install(PROGRAMS ${SAMPLES_SOURCE}/windows/oodialog/ooRexxTry/ooRexxTry.rex COMPONENT Core DESTINATION ${INSTALL_EXECUTABLE_DIR})

   # add extra shortcuts (uninstall one is automatically added)
   install_rexx_shortcut(Core "Try Rexx" rexx rexxtry.rex)
   install_rexx_shortcut(Core "Try Rexx (GUI)" rexx ooRexxTry.rex)
   install_component_shortcut(Core "ooRexx License" CPLv1.0.txt "" CPLv1.0.txt 0)

   # now the samples

   install(FILES ${SAMPLES_SOURCE}/windows/0ReadMe.first COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})
   install(PROGRAMS ${SAMPLES_SOURCE}/windows/rexutils/drives.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR})

   # misc samples
   install(FILES ${SAMPLES_SOURCE}/windows/misc/fileDrop.empty COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR}/misc)
   install(FILES ${SAMPLES_SOURCE}/windows/misc/fileDrop.input COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR}/misc)
   install(FILES ${SAMPLES_SOURCE}/windows/misc/fileDrop.readMe COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR}/misc)
   install(PROGRAMS ${SAMPLES_SOURCE}/windows/misc/fileDrop.rex COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR}/misc)

   # ole samples
   install(DIRECTORY ${SAMPLES_SOURCE}/windows/ole COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR} PATTERN ".svn" EXCLUDE)

   # oodialog samples
   install(DIRECTORY ${SAMPLES_SOURCE}/windows/oodialog COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR} PATTERN ".svn" EXCLUDE)
   install(FILES ${build_extensions_oodialog_dir}/oodialog.ico COMPONENT Samples DESTINATION ${INSTALL_SAMPLES_DIR}/oodialog)

   # sample shortcuts
   # NOTE:  because of multiple levels of escaping going on, the subdirectory "\" require FOUR backslashes
   install_rexx_shortcut(Samples "ooRexx Samples\\\\RexxCPS" rexxpaws "samples\\\\rexxcps.rex")
   install_rexx_shortcut(Samples "ooRexx Samples\\\\Query Date" rexxpaws "samples\\\\qdate.rex")
   install_rexx_shortcut(Samples "ooRexx Samples\\\\Display Window Tree" ooDialog "samples\\\\oodialog\\\\winsystem\\\\displayWindowTree.rex")
   install_rexx_shortcut(Samples "ooRexx Samples\\\\Windows Manager" ooDialog "samples\\\\oodialog\\\\winsystem\\\\usewmgr.rex")
   install_rexx_shortcut(Samples "ooRexx Samples\\\\ooDialog\\\\Combo Box Types" ooDialog "samples\\\\oodialog\\\\Controls\\\\ComboBox\\\\comboBoxTypes.rex")
   install_rexx_shortcut(Samples "ooRexx Samples\\\\ooDialog\\\\Custom Position Tool Tips" ooDialog "samples\\\\oodialog\\\\Controls\\\\ToolTip\\\\customPositionToolTip.rex")
   install_rexx_shortcut(Samples "ooRexx Samples\\\\ooDialog\\\\List-view Views" ooDialog "samples\\\\oodialog\\\\Controls\\\\ListView\\\\columnIcons.rex")
   install_rexx_shortcut(Samples "ooRexx Samples\\\\ooDialog\\\\Samples" ooDialog "samples\\\\sample.rex")
   install_component_shortcut(Samples "ooRexx Samples\\\\API\\\\Call ooRexx in a Console" "samples\\\\api\\\\callrxnt\\\\callrxnt.exe" "" "samples\\\\api\\\\callrxnt\\\\callrxnt.ico" "")
   install_component_shortcut(Samples "ooRexx Samples\\\\API\\\\Call ooRexx in a Window" "samples\\\\api\\\\callrxwn\\\\callrxwn.exe" "" "samples\\\\api\\\\callrxwn\\\\callrxwn.ico" "")
   install_component_shortcut(Samples "ooRexx Samples\\\\API\\\\Call ooRexx with Exits" "samples\\\\api\\\\rexxexit\\\\rexxexit.exe" "" "samples\\\\api\\\\rexxexit\\\\rexxexit.ico" "")

   # if we have a doc source directory, then add the Docs component to the installer and
   # install each of the doc files
   install(FILES ${DOC_SOURCE_DIR}/readme.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/CHANGES COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR} RENAME CHANGES.txt)
   install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/ReleaseNotes COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR} RENAME ReleaseNotes.txt)
   install(FILES ${DOC_SOURCE_DIR}/rexxapi.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${DOC_SOURCE_DIR}/rexxpg.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${DOC_SOURCE_DIR}/rexxref.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${DOC_SOURCE_DIR}/rxmath.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${DOC_SOURCE_DIR}/rxsock.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${DOC_SOURCE_DIR}/rxftp.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${DOC_SOURCE_DIR}/oodialog.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${build_extensions_oodialog_dir}/ooDialog_ReleaseNotes.txt COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${DOC_SOURCE_DIR}/oodguide.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${DOC_SOURCE_DIR}/rexxextensions.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${DOC_SOURCE_DIR}/winextensions.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
   install(FILES ${SAMPLES_SOURCE}/windows/oodialog/ooRexxTry/doc/ooRexxTry.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})

   install_doc_shortcut("ooRexx README" "readme.pdf")
   install_doc_shortcut("ooRexx CHANGES" "CHANGES.txt")
   install_doc_shortcut("ooRexx Release Notes" "ReleaseNotes.txt")
   install_doc_shortcut("ooRexx Reference" "rexxref.pdf")
   install_doc_shortcut("ooRexx APIs (Application Programming Interfaces)" "rexxapi.pdf")
   install_doc_shortcut("ooRexx Programming Guide" "rexxpg.pdf")
   install_doc_shortcut("ooRexx Mathematical Functions Reference" "rxmath.pdf")
   install_doc_shortcut("ooRexx TCP/IP Socket Functions Reference" "rxsock.pdf")
   install_doc_shortcut("ooRexx RxFtp Class Library Reference" "rxftp.pdf")
   install_doc_shortcut("ooDialog Reference" "oodialog.pdf")
   install_doc_shortcut("ooDialog Release Notes" "ooDialog_ReleaseNotes.txt")
   install_doc_shortcut("ooDialog User Guide" "oodguide.pdf")
   install_doc_shortcut("ooRexx Extensions Reference" "rexxextensions.pdf")
   install_doc_shortcut("ooRexx Windows Reference" "winextensions.pdf")
   install_doc_shortcut("ooRexxTry Reference" "ooRexxTry.pdf")

   # build the NSIS shortcut creation/deletion macros that are inserted into the template
   configure_file(${NSIS_INSTALLER_SOURCE_DIR}/Core_shortcut_manifest.nsh.in ${NSIS_INSTALLER_DIR}/Core_shortcut_manifest.nsh @ONLY)
   configure_file(${NSIS_INSTALLER_SOURCE_DIR}/Docs_shortcut_manifest.nsh.in ${NSIS_INSTALLER_DIR}/Docs_shortcut_manifest.nsh @ONLY)
   configure_file(${NSIS_INSTALLER_SOURCE_DIR}/DevLib_shortcut_manifest.nsh.in ${NSIS_INSTALLER_DIR}/DevLib_shortcut_manifest.nsh @ONLY)
   configure_file(${NSIS_INSTALLER_SOURCE_DIR}/Samples_shortcut_manifest.nsh.in ${NSIS_INSTALLER_DIR}/Samples_shortcut_manifest.nsh @ONLY)

   # Build an NSIS installer without using CPack
   find_program(NSIS_EXECUTABLE makensis DOC "NSIS Compiler")

   # only do this if we have NSIS installed
   if (NSIS_EXECUTABLE)
      # we're using verbatim for the command, so we need to get the
      # directories in native form first
      file(TO_NATIVE_PATH ${CMAKE_CURRENT_SOURCE_DIR} NATIVE_SOURCE_DIR)
      file(TO_NATIVE_PATH ${CMAKE_CURRENT_BINARY_DIR}/bin NATIVE_BINARY_DIR)
      file(TO_NATIVE_PATH ${DOC_SOURCE_DIR} NATIVE_DOC_DIR)

      # Name of the installer file we're going to create
      if (DEFINED OS_DIST)
         set(INSTALLER_FILE "${CPACK_PACKAGE_NAME}-${ORX_VERSION_NSIS}.${OS_DIST}.${NSIS_CPU}.exe")
         set(INSTALLER_SCRIPT "${CPACK_PACKAGE_NAME}-${ORX_VERSION_NSIS}.${OS_DIST}.${NSIS_CPU}.nsi")
      else ()
         set(INSTALLER_FILE "${CPACK_PACKAGE_NAME}-${ORX_VERSION_NSIS}.windows.${NSIS_CPU}.exe")
         set(INSTALLER_SCRIPT "${CPACK_PACKAGE_NAME}-${ORX_VERSION_NSIS}.windows.${NSIS_CPU}.nsi")
      endif ()

      # create an installer file from the template
      message(STATUS "Building NSIS template ${INSTALLER_SCRIPT}")
      configure_file(${NSIS_INSTALLER_SOURCE_DIR}/cpack.nsi.template.in ${NSIS_INSTALLER_DIR}/${INSTALLER_SCRIPT} @ONLY)

   # handy macro for copying files from the source into the source directory.
   macro (copy_install_file name)
       ADD_CUSTOM_COMMAND(
          OUTPUT ${NSIS_INSTALLER_DIR}/${name}
          COMMAND ${CMAKE_COMMAND} -E copy ${NSIS_INSTALLER_SOURCE_DIR}/${name} ${NSIS_INSTALLER_DIR}/${name}
          DEPENDS ${NSIS_INSTALLER_SOURCE_DIR}/${name}
       )
   endmacro (copy_install_file)

      add_custom_target(nsis_installer
         DEPENDS ${DOC_SOURCE_DIR}/readme.pdf
                 ${DOC_SOURCE_DIR}/rexxapi.pdf
                 ${DOC_SOURCE_DIR}/rexxpg.pdf
                 ${DOC_SOURCE_DIR}/rexxref.pdf
                 ${DOC_SOURCE_DIR}/rxmath.pdf
                 ${DOC_SOURCE_DIR}/rxsock.pdf
                 ${DOC_SOURCE_DIR}/rxftp.pdf
                 ${DOC_SOURCE_DIR}/oodialog.pdf
                 ${DOC_SOURCE_DIR}/oodguide.pdf
                 ${DOC_SOURCE_DIR}/rexxextensions.pdf
                 ${DOC_SOURCE_DIR}/winextensions.pdf
                 ${build_platform_dir}/install/cpack.nsi
         VERBATIM
         COMMAND ${NSIS_EXECUTABLE} /DVERSION=${ORX_VERSION_NSIS} /DSRCDIR=${NATIVE_SOURCE_DIR} /DBINDIR=${NATIVE_BINARY_DIR} /DDOCDIR=${NATIVE_DOC_DIR} /DCPU=${NSIS_CPU} cpack.nsi
         WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/${build_platform_dir}/install
         COMMAND ${CMAKE_COMMAND} -E copy ${CMAKE_CURRENT_SOURCE_DIR}/${build_platform_dir}/install/${INSTALLER_FILE} ${CMAKE_CURRENT_BINARY_DIR}/${INSTALLER_FILE}
         COMMAND ${CMAKE_COMMAND} -E remove ${CMAKE_CURRENT_SOURCE_DIR}/${build_platform_dir}/install/${INSTALLER_FILE}
         COMMENT "Building NSIS installer")

      # copy additional include files required by the makensis command
      copy_install_file(admin.nsh)
      copy_install_file(newpath.nsh)
      copy_install_file(WriteEnv.nsh)
      copy_install_file(orange.bmp)
      copy_install_file(orange-uninstall.bmp)

      # a target to make sure these get copied (not part of ALL, but the installer will depend on it
      add_custom_target(nsis_includes DEPENDS
         ${NSIS_INSTALLER_DIR}/admin.nsh
         ${NSIS_INSTALLER_DIR}/newpath.nsh
         ${NSIS_INSTALLER_DIR}/WriteEnv.nsh
         ${NSIS_INSTALLER_DIR}/orange.bmp
         ${NSIS_INSTALLER_DIR}/orange-uninstall.bmp)

      # Target for building an NSIS installation.  This will copy all of the install
      # files into a directory structure that mimics how.  We do this in 4 stages to install each of
      # the components into a different directory, since them might install files into common directories
      # at install time.
      add_custom_target(nsis_install_dirs
         DEPENDS ${CMAKE_CURRENT_BINARY_DIR}/cmake_install.cmake
         WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
         COMMAND ${CMAKE_COMMAND} -DCMAKE_INSTALL_COMPONENT=Core -DCMAKE_INSTALL_PREFIX=${NSIS_FILE_DIR}/Core -P ${CMAKE_CURRENT_BINARY_DIR}/cmake_install.cmake
         COMMAND ${CMAKE_COMMAND} -DCMAKE_INSTALL_COMPONENT=Docs -DCMAKE_INSTALL_PREFIX=${NSIS_FILE_DIR}/Docs -P ${CMAKE_CURRENT_BINARY_DIR}/cmake_install.cmake
         COMMAND ${CMAKE_COMMAND} -DCMAKE_INSTALL_COMPONENT=DevLib -DCMAKE_INSTALL_PREFIX=${NSIS_FILE_DIR}/DevLib -P ${CMAKE_CURRENT_BINARY_DIR}/cmake_install.cmake
         COMMAND ${CMAKE_COMMAND} -DCMAKE_INSTALL_COMPONENT=Samples -DCMAKE_INSTALL_PREFIX=${NSIS_FILE_DIR}/Samples -P ${CMAKE_CURRENT_BINARY_DIR}/cmake_install.cmake
         COMMENT "Building NSIS file install structure")

      # Target for building the NSIS file manifests from the install information
      add_custom_target(nsis_file_manifests
         DEPENDS nsis_install_dirs
         WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
         COMMAND ${CMAKE_COMMAND} -DBINARY_DIR=${CMAKE_CURRENT_BINARY_DIR} -P ${CMAKE_CURRENT_SOURCE_DIR}/${build_platform_dir}/install/BuildComponentManifests.cmake
         COMMENT "Building NSIS file install manifests")

      # and finally, build the installer manifests
      add_custom_target(nsis_template_installer
         DEPENDS nsis_file_manifests
                 nsis_install_dirs
                 nsis_includes
                 ${NSIS_INSTALLER_DIR}/${INSTALLER_SCRIPT}
         VERBATIM
         COMMAND ${NSIS_EXECUTABLE} ${INSTALLER_SCRIPT}
         WORKING_DIRECTORY ${NSIS_INSTALLER_DIR}
         COMMENT "Building NSIS installer from template in ${NSIS_INSTALLER_DIR}")

      # an extra to cleanup the installer directory to start fresh
      add_custom_target(remove_nsis_installer
          COMMAND ${CMAKE_COMMAND} -E remove_directory ${NSIS_INSTALLER_DIR}
          WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
          COMMENT "Removing NSIS installer build files")
   endif()

   else () # Unix
	   # install each of the doc files
	   install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/CHANGES COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR} RENAME CHANGES.txt)
	   install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/ReleaseNotes COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR} RENAME ReleaseNotes.txt)

	   install(FILES ${DOC_SOURCE_DIR}/readme.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
	   install(FILES ${DOC_SOURCE_DIR}/orxncurses.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})

	   install(FILES ${DOC_SOURCE_DIR}/rexxapi.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
	   install(FILES ${DOC_SOURCE_DIR}/rexxextensions.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})

	   install(FILES ${DOC_SOURCE_DIR}/rexxpg.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
	   install(FILES ${DOC_SOURCE_DIR}/rexxref.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
	   install(FILES ${DOC_SOURCE_DIR}/rxmath.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
	   install(FILES ${DOC_SOURCE_DIR}/rxsock.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})
	   install(FILES ${DOC_SOURCE_DIR}/rxftp.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})

	   install(FILES ${DOC_SOURCE_DIR}/unixextensions.pdf COMPONENT Docs DESTINATION ${INSTALL_DOC_DIR})

   endif()
endif ()


#################### Unix Package Targets ##########################
#################### Unix Package Targets ##########################
#################### Unix Package Targets ##########################
#################### Unix Package Targets ##########################
#################### Unix Package Targets ##########################

# Build an RPM
if (BUILD_RPM)
   # Set up the desktop menu
   SET(ORX_DESKTOP_DIR share/applications)
   SET(ORX_PIXMAPS_DIR share/icons/hicolor/48x48/apps)
   configure_file(${ORX_PLATFORM_DIR}/menu/rexxtry.desktop.in ${PROJECT_BINARY_DIR}/rexxtry.desktop)
   INSTALL (FILES ${PROJECT_BINARY_DIR}/rexxtry.desktop DESTINATION ${ORX_DESKTOP_DIR})
   #INSTALL (FILES ${ORX_PLATFORM_DIR}/menu/rexxtry.xml DESTINATION ${ORX_DESKTOP_DIR})
   # Copy the ooRexx pixmap
   INSTALL (FILES ${ORX_PLATFORM_DIR}/oorexx.png DESTINATION ${ORX_PIXMAPS_DIR})
   # try to set up the menu system
   find_program(XDG-MIME_EXECUTABLE xdg-mime)
   find_program(XDG-DESKTOP-MENU_EXECUTABLE xdg-desktop-menu)
   INSTALL(CODE "
     #execute_process(COMMAND ${XDG-MIME_EXECUTABLE} install --novendor ${CMAKE_INSTALL_PREFIX}/${ORX_DESKTOP_DIR}/rexxtry.xml)
     execute_process(COMMAND ${XDG-DESKTOP-MENU_EXECUTABLE} install --novendor ${CMAKE_INSTALL_PREFIX}/${ORX_DESKTOP_DIR}/rexxtry.desktop)
     execute_process(COMMAND ${XDG-MIME_EXECUTABLE} default ${CMAKE_INSTALL_PREFIX}/${ORX_DESKTOP_DIR}/rexxtry.desktop application/x-ooRexx-item)
     ")
   # This prevents the rpm from generating these subdirectories in the install.
   set(CPACK_RPM_EXCLUDE_FROM_AUTO_FILELIST_ADDITION
      ${CMAKE_INSTALL_PREFIX}
      ${CMAKE_INSTALL_PREFIX}/bin
      ${CMAKE_INSTALL_PREFIX}/lib
      ${CMAKE_INSTALL_PREFIX}/lib64
      ${CMAKE_INSTALL_PREFIX}/include
      ${CMAKE_INSTALL_PREFIX}/share
      ${CMAKE_INSTALL_PREFIX}/share/man
      ${CMAKE_INSTALL_PREFIX}/share/man/man1
      ${CMAKE_INSTALL_PREFIX}/share/applications
      ${CMAKE_INSTALL_PREFIX}/share/icons)
   set(CPACK_GENERATOR RPM)
   set(CPACK_RPM_PACKAGE_NAME ${CPACK_PACKAGE_NAME})
   if (DEFINED PROD)
      set(CPACK_PACKAGE_RELEASE 1)
   else ()
      set(CPACK_PACKAGE_RELEASE ${ORX_BLD_LVL})
   endif ()

# changed from ORX_VERSION to ORX_VER_STR because ORX_VERSION is redefined for versioning
# resulting in an incorrect version number here
   set(CPACK_RPM_PACKAGE_VERSION ${ORX_VER_STR})
   set(CPACK_RPM_PACKAGE_RELEASE ${CPACK_PACKAGE_RELEASE})
   set(CPACK_RPM_PACKAGE_LICENSE "CPL")
   set(CPACK_RPM_PACKAGE_URL "https://www.oorexx.org/")
   set(CPACK_PACKAGE_CONTACT "sahananda@users.sf.net")
   set(CPACK_RPM_PACKAGE_GROUP "Development/Languages")
   set(CPACK_RPM_PACKAGE_VENDOR "Rexx Language Association")
   set(CPACK_PACKAGING_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")
   set(CPACK_RPM_PACKAGE_SUMMARY "Open Object Rexx is an object-oriented scripting language.")

   set(CPACK_RPM_PACKAGE_ARCHITECTURE ${CMAKE_SYSTEM_PROCESSOR})
   if (DEFINED OS_DIST)
      set(CPACK_PACKAGE_FILE_NAME "${CPACK_PACKAGE_NAME}-${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL}-${CPACK_PACKAGE_RELEASE}.${OS_DIST}.${CMAKE_SYSTEM_PROCESSOR}")
   else ()
      set(CPACK_PACKAGE_FILE_NAME "${CPACK_PACKAGE_NAME}-${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL}-${CPACK_PACKAGE_RELEASE}.${CMAKE_SYSTEM_PROCESSOR}")
   endif ()
   set(CPACK_RPM_PACKAGE_DESCRIPTION
"Open Object Rexx is an object-oriented scripting language. The language
is designed for both beginners and experienced Rexx programmers. It is
easy to learn and use, and provides an excellent vehicle to enter the
world of object-oriented programming without much effort.

It extends the procedural way of Rexx programming with object-oriented
features that allow you to gradually change your programming style as
you learn more about objects.

For more information on ooRexx, visit https://www.oorexx.org/
For more information on Rexx, visit https://www.rexxla.org/")
endif ()

# Build a DEB
if (BUILD_DEB)
   # Set up the desktop menu
   SET(ORX_DESKTOP_DIR share/applications)
   SET(ORX_PIXMAPS_DIR share/icons)
   configure_file(${ORX_PLATFORM_DIR}/menu/rexxtry.desktop.in ${PROJECT_BINARY_DIR}/rexxtry.desktop)
   INSTALL (FILES ${PROJECT_BINARY_DIR}/rexxtry.desktop DESTINATION ${ORX_DESKTOP_DIR})
   #INSTALL (FILES ${ORX_PLATFORM_DIR}/menu/rexxtry.xml DESTINATION ${ORX_DESKTOP_DIR})
   # Copy the ooRexx pixmap
   INSTALL (FILES ${ORX_PLATFORM_DIR}/oorexx.png DESTINATION ${ORX_PIXMAPS_DIR})
   # try to set up the menu system
   find_program(XDG-MIME_EXECUTABLE xdg-mime)
   find_program(XDG-DESKTOP-MENU_EXECUTABLE xdg-desktop-menu)
   INSTALL(CODE "
     #execute_process(COMMAND ${XDG-MIME_EXECUTABLE} install --novendor ${CMAKE_INSTALL_PREFIX}/${ORX_DESKTOP_DIR}/rexxtry.xml)
     execute_process(COMMAND ${XDG-DESKTOP-MENU_EXECUTABLE} install --novendor ${CMAKE_INSTALL_PREFIX}/${ORX_DESKTOP_DIR}/rexxtry.desktop)
     execute_process(COMMAND ${XDG-MIME_EXECUTABLE} default ${CMAKE_INSTALL_PREFIX}/${ORX_DESKTOP_DIR}/rexxtry.desktop application/x-ooRexx-item)
     ")
   set(CPACK_GENERATOR DEB)
   # The package name MUST be in lower case.
   set(CPACK_DEBIAN_PACKAGE_NAME ${CPACK_PACKAGE_NAME})
   if (DEFINED PROD)
      set(CPACK_PACKAGE_RELEASE 1)
   else ()
      set(CPACK_PACKAGE_RELEASE ${ORX_BLD_LVL})
   endif ()
   set(CPACK_DEBIAN_PACKAGE_SECTION "devel")
   set(CPACK_DEBIAN_PACKAGE_HOMEPAGE "https://www.oorexx.org/")
   set(CPACK_PACKAGE_CONTACT "sahananda@users.sf.net")
   set(CPACK_DEBIAN_PACKAGE_MAINTAINER "sahananda@users.sf.net")
   set(CPACK_PACKAGING_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")
   if (DEFINED OS_DIST)
      set(CPACK_PACKAGE_FILE_NAME "${CPACK_PACKAGE_NAME}-${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL}-${CPACK_PACKAGE_RELEASE}.${OS_DIST}.${CMAKE_SYSTEM_PROCESSOR}")
   else ()
      set(CPACK_PACKAGE_FILE_NAME "${CPACK_PACKAGE_NAME}-${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL}-${CPACK_PACKAGE_RELEASE}.${CMAKE_SYSTEM_PROCESSOR}")
   endif ()
   # The DEB generator does not support a multi-line description.
   set(CPACK_DEBIAN_PACKAGE_DESCRIPTION "Open Object Rexx is an object-oriented scripting language.")
endif ()

# Build for FREEBSD
if (BUILD_FREEBSD)
   set(CPACK_GENERATOR FREEBSD)
   set(CPACK_FREEBSD_PACKAGE_NAME ${CPACK_PACKAGE_NAME})
   if (DEFINED PROD)
      set(CPACK_PACKAGE_RELEASE 1)
   else ()
      set(CPACK_PACKAGE_RELEASE ${ORX_BLD_LVL})
   endif ()
   set(CPACK_FREEBSD_PACKAGE_MAINTAINER "sahananda@users.sf.net")
   set(CPACK_PACKAGING_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")
   if (DEFINED OS_DIST)
      set(CPACK_PACKAGE_FILE_NAME "${CPACK_PACKAGE_NAME}-${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL}-${CPACK_PACKAGE_RELEASE}.${OS_DIST}.${CMAKE_SYSTEM_PROCESSOR}")
   else ()
      set(CPACK_PACKAGE_FILE_NAME "${CPACK_PACKAGE_NAME}-${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL}-${CPACK_PACKAGE_RELEASE}.${CMAKE_SYSTEM_PROCESSOR}")
   endif ()
   set(CPACK_FREEBSD_PACKAGE_LICENSE "CPL")
   set(CPACK_FREEBSD_PACKAGE_DESCRIPTION
"Open Object Rexx is an object-oriented scripting language. The language
is designed for both beginners and experienced Rexx programmers. It is
easy to learn and use, and provides an excellent vehicle to enter the
world of object-oriented programming without much effort.

It extends the procedural way of Rexx programming with object-oriented
features that allow you to gradually change your programming style as
you learn more about objects.

For more information on ooRexx, visit https://www.oorexx.org/
For more information on Rexx, visit https://www.rexxla.org/")
endif ()

# Build for Apple macOS, fallback when OS not defined
if (NOT DEFINED OS_DIST AND APPLE)
   set(OS_DIST "macos")
endif ()

if (BUILD_DMG)
# The installer is built in a post-process script build_macOS_dmg.sh.in
# initialised from platform/unix/macos/install/build_macOS_dmg.sh.in
# using settings from here

# Always 64 bit for macOS; as of rev 12671 it should be all lowercase

# This is copied from DEB & RPM Installers
   if (DEFINED PROD)
      set(CPACK_PACKAGE_RELEASE 1)
   else ()
      set(CPACK_PACKAGE_RELEASE ${ORX_BLD_LVL})
   endif ()

# This was changed to cope with arm64 or x86_64 or both
   if( APPLE AND BUILD_OSX_UNIVERSAL_BINARIES )
      set(CPACK_PACKAGE_FILE_NAME "${CPACK_PACKAGE_NAME}-${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL}-${CPACK_PACKAGE_RELEASE}.${OS_DIST}.arm64.x86_64")
   else ()
      set(CPACK_PACKAGE_FILE_NAME "${CPACK_PACKAGE_NAME}-${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL}-${CPACK_PACKAGE_RELEASE}.${OS_DIST}.${CMAKE_SYSTEM_PROCESSOR}")
   endif ()

   message(STATUS "ORX_BLD_LVL ${ORX_BLD_LVL}")
   message(STATUS "CPACK_PACKAGE_RELEASE ${CPACK_PACKAGE_RELEASE}")
   message(STATUS "CPACK_PACKAGE_FILE_NAME ${CPACK_PACKAGE_FILE_NAME}")

   # Be sure to do this AFTER you set the CPACK_PACKAGE_FILE_NAME

   configure_file( ${CMAKE_SOURCE_DIR}/platform/unix/macos/install/build_macOS_dmg.sh.in ${CMAKE_BINARY_DIR}/build_macOS_dmg.sh IMMEDIATE @ONLY )

endif ()


######################  portable Rexx Home ENVironment archive  ##########################
set (zip_dir_name           _portable_)
set (run_rexx_exe           ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/rexx)
set (run_rexx_create_script ${CMAKE_CURRENT_SOURCE_DIR}/support/portable/createPortable.rex)

if (WIN32)
   set (rexx_exe_cpu ${NSIS_CPU})
   set (rexx_exe_shell_ft cmd)
else  () # Unix
   set (rexx_exe_shell_ft sh)

   if( APPLE AND BUILD_OSX_UNIVERSAL_BINARIES )
      set(rexx_exe_cpu "universal")
   else ()
      set(rexx_exe_cpu ${CMAKE_SYSTEM_PROCESSOR})
   endif ()
endif ()
string(TOLOWER "${CMAKE_BUILD_TYPE}" rexx_build_type)

if (DEFINED CPACK_PACKAGE_FILE_NAME)
   # use the installation package name, if defined
   set (zip_name "${CPACK_PACKAGE_FILE_NAME}-portable-${rexx_build_type}")
else ()
   # field sequence should follow as closely as possible the installation package name
   set (zip_name "${CPACK_PACKAGE_NAME}-${ORX_VER_STR}-${ORX_BLD_LVL}.${OS_DIST}.${rexx_exe_cpu}-portable-${rexx_build_type}")
endif ()

add_custom_target(portable
  COMMAND ${CMAKE_COMMAND} -E remove_directory "${zip_dir_name}"  # make sure directory gets removed
  # Rexx program that does a DESTDIR local install and creates the zip directory structure
  COMMAND ${run_rexx_exe}  ${run_rexx_create_script} -portable_dirname ${zip_dir_name} -zip_name ${zip_name}

  # change into temporary directory and create full archive
  COMMAND ${CMAKE_COMMAND} -E chdir "${zip_dir_name}"
          ${CMAKE_COMMAND} -E tar "cfv" "${zip_name}.zip" --format=zip
                                 "${zip_name}"

  # copy archives
  COMMAND ${CMAKE_COMMAND} -E copy "${zip_dir_name}/${zip_name}.zip" "${CMAKE_CURRENT_BINARY_DIR}"

  # delete archives
  COMMAND ${CMAKE_COMMAND} -E remove "${zip_dir_name}/${zip_name}.zip"

  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  COMMENT "Creating portable Rexx Home ENVironment zip archive ...")
# <-- portable Rexx Home ENVironment archive <--

# Create a source package
if(BUILD_SOURCE)
  set(CPACK_PACKAGING_INSTALL_PREFIX "/")
  set(CPACK_SOURCE_GENERATOR "TGZ")
  set(CPACK_SOURCE_PACKAGE_FILE_NAME "${CPACK_PACKAGE_NAME}-${ORX_MAJOR}.${ORX_MINOR}.${ORX_MOD_LVL}-${CPACK_PACKAGE_RELEASE}")
  message(STATUS "CPACK_PACKAGING_INSTALL_PREFIX ${CPACK_PACKAGING_INSTALL_PREFIX}")
  message(STATUS "CPACK_SOURCE_PACKAGE_FILE_NAME ${CPACK_SOURCE_PACKAGE_FILE_NAME}")
endif ()

# Do not move the following statement!! It must be the last statement in this file.
include(CPack)
