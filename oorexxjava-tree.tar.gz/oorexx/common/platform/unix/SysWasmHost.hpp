/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Copyright (c) 2026 Rexx Language Association. All rights reserved.         */
/*                                                                            */
/* This program and the accompanying materials are made available under       */
/* the terms of the Common Public License v1.0 which accompanies this         */
/* distribution. A copy is also available at the following address:           */
/* https://www.oorexx.org/license.html                                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/**
 * WebAssembly builds (ORX_WASM: Emscripten or WASI): what the interpreter
 * asks of the host that runs it, and what it gives the host.
 *
 * The host functions below are weak symbols.  A runtime that has the
 * facility defines them (the Emscripten build, under Node, with JavaScript;
 * a WASI build with functions imported from its host); in a runtime that
 * defines none they are NULL, and the interpreter does without: commands
 * fail as unknown (FAILURE, RC 127, after the commands it handles itself,
 * such as CD and EXPORT), and .RexxInfo~executable is .nil.
 */
#ifndef Included_SysWasmHost
#define Included_SysWasmHost

#if defined(ORX_WASM)

#if defined(__EMSCRIPTEN__)
#include <emscripten/emscripten.h>
// a function of the interpreter that the host calls
#define ORX_WASM_EXPORT(name) EMSCRIPTEN_KEEPALIVE
#else
#define ORX_WASM_EXPORT(name) __attribute__((export_name(#name)))
#endif

// flags for orxWasmCommandRun()
#define WASM_CMD_INPUT      1      // input: inputLength bytes at input
#define WASM_CMD_OUTPUT     2      // collect the output (orxWasmCommandResultCopy(0))
#define WASM_CMD_ERROR      4      // collect the error output (orxWasmCommandResultCopy(1))
#define WASM_CMD_SAME       8      // OUTPUT and ERROR to the same target, interleaved

// orxWasmCommandRun(): the host has no processes
#define WASM_CMD_NO_PROCESSES  (-100000)

extern "C"
{
/**
 * Run a command as a process of the host and wait for it.  Without the
 * flags its standard streams are the interpreter's.
 *
 * @param argv   The program and its arguments (NULL-terminated).
 * @param envp   The environment (NULL-terminated "name=value" strings).
 * @param cwd    The current directory, or NULL.
 * @param input  The input, with WASM_CMD_INPUT.
 * @param inputLength Its length.
 * @param flags  WASM_CMD_* flags.
 *
 * @return The exit status (>= 0), -signal if a signal ended it, 127 if the
 *         command could not be started, or WASM_CMD_NO_PROCESSES.
 */
int orxWasmCommandRun(char **argv, char **envp, const char *cwd,
                      const char *input, int inputLength, int flags) __attribute__((weak));
// the length of the output (which 0) or error output (1) collected by the
// last orxWasmCommandRun() of this thread
int orxWasmCommandResultLength(int which) __attribute__((weak));
// copy it to buf and drop it
void orxWasmCommandResultCopy(int which, char *buf) __attribute__((weak));

/**
 * The full path of the program that runs Rexx programs here (what a native
 * build finds in /proc/self/exe), into buf; 0 if there is none or it does
 * not fit.  .RexxInfo~executable.
 */
int orxWasmExecutablePath(char *buf, int size) __attribute__((weak));
/**
 * The directory of the interpreter's files (rexx.img, the extensions'
 * classes), with a trailing slash, into buf; 0 if there is none or it does
 * not fit.  .RexxInfo~libraryPath.
 */
int orxWasmLibraryDirectory(char *buf, int size) __attribute__((weak));
}

// The interpreter gives the host (SystemInterpreter.cpp):
//   int orxWasmSignal(int sig): what a native signal handler does for SIGINT,
//   SIGTERM or SIGHUP (a HALT in every activity, sleeps end with EINTR);
//   the host calls it, from any thread, when it gets such a signal.

#endif
#endif
