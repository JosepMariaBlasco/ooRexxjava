/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Copyright (c) 1995, 2004 IBM Corporation. All rights reserved.             */
/* Copyright (c) 2005-2025 Rexx Language Association. All rights reserved.    */
/*                                                                            */
/* This program and the accompanying materials are made available under       */
/* the terms of the Common Public License v1.0 which accompanies this         */
/* distribution. A copy is also available at the following address:           */
/* https://www.oorexx.org/license.html                                        */
/*                                                                            */
/* Redistribution and use in source and binary forms, with or                 */
/* without modification, are permitted provided that the following            */
/* conditions are met:                                                        */
/*                                                                            */
/* Redistributions of source code must retain the above copyright             */
/* notice, this list of conditions and the following disclaimer.              */
/* Redistributions in binary form must reproduce the above copyright          */
/* notice, this list of conditions and the following disclaimer in            */
/* the documentation and/or other materials provided with the distribution.   */
/*                                                                            */
/* Neither the name of Rexx Language Association nor the names                */
/* of its contributors may be used to endorse or promote products             */
/* derived from this software without specific prior written permission.      */
/*                                                                            */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        */
/* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          */
/* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          */
/* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   */
/* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED   */
/* TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,        */
/* OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY     */
/* OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING    */
/* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS         */
/* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.               */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/*****************************************************************************/
/*                                                                           */
/* Process support for Unix based systems.                                   */
/*                                                                           */
/*****************************************************************************/

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include <pwd.h>
#include <dlfcn.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include "SysProcess.hpp"
#include "SysThread.hpp"
#include "rexx.h"
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <errno.h>
#ifdef HAVE_KDMKTONE
# include <linux/kd.h>
#endif
#ifdef HAVE_NSGETEXECUTABLEPATH
# include <mach-o/dyld.h>
#endif
#if defined HAVE_KERN_PROC_PATHNAME || defined HAVE_KERN_PROC_ARGV
# include <sys/sysctl.h>
#endif


// full path of the currently running executable
const char *SysProcess::executableFullPath = NULL;
// directory of our Rexx shared libraries
const char *SysProcess::libraryLocation = NULL;

#include "SysWasmHost.hpp"

#if defined(ORX_WASM)
// WASI errno (what the Emscripten libc and wasi-libc return) -> Linux errno.  Error
// numbers reach Rexx programs (RC of CD, stream descriptions ERROR:n,
// SysMkDir, SysFileDelete, ...), which are written against the Linux values.
static const struct { int wasm; int host; } wasmErrnoTable[] =
{
    { EPERM, 1 },
    { ENOENT, 2 },
    { ESRCH, 3 },
    { EINTR, 4 },
    { EIO, 5 },
    { ENXIO, 6 },
    { E2BIG, 7 },
    { ENOEXEC, 8 },
    { EBADF, 9 },
    { ECHILD, 10 },
    { EAGAIN, 11 },
    { ENOMEM, 12 },
    { EACCES, 13 },
    { EFAULT, 14 },
    { EBUSY, 16 },
    { EEXIST, 17 },
    { EXDEV, 18 },
    { ENODEV, 19 },
    { ENOTDIR, 20 },
    { EISDIR, 21 },
    { EINVAL, 22 },
    { ENFILE, 23 },
    { EMFILE, 24 },
    { ENOTTY, 25 },
    { ETXTBSY, 26 },
    { EFBIG, 27 },
    { ENOSPC, 28 },
    { ESPIPE, 29 },
    { EROFS, 30 },
    { EMLINK, 31 },
    { EPIPE, 32 },
    { EDOM, 33 },
    { ERANGE, 34 },
    { EDEADLK, 35 },
    { ENAMETOOLONG, 36 },
    { ENOLCK, 37 },
    { ENOSYS, 38 },
    { ENOTEMPTY, 39 },
    { ELOOP, 40 },
    { ENOMSG, 42 },
    { EIDRM, 43 },
    { ENOLINK, 67 },
    { EPROTO, 71 },
    { EMULTIHOP, 72 },
    { EBADMSG, 74 },
    { EOVERFLOW, 75 },
    { EILSEQ, 84 },
    { ENOTSOCK, 88 },
    { EDESTADDRREQ, 89 },
    { EMSGSIZE, 90 },
    { EPROTOTYPE, 91 },
    { ENOPROTOOPT, 92 },
    { EPROTONOSUPPORT, 93 },
    { EAFNOSUPPORT, 97 },
    { EADDRINUSE, 98 },
    { EADDRNOTAVAIL, 99 },
    { ENETDOWN, 100 },
    { ENETUNREACH, 101 },
    { ENETRESET, 102 },
    { ECONNABORTED, 103 },
    { ECONNRESET, 104 },
    { ENOBUFS, 105 },
    { EISCONN, 106 },
    { ENOTCONN, 107 },
    { ETIMEDOUT, 110 },
    { ECONNREFUSED, 111 },
    { EHOSTUNREACH, 113 },
    { EALREADY, 114 },
    { EINPROGRESS, 115 },
    { ESTALE, 116 },
    { EDQUOT, 122 },
    { ECANCELED, 125 },
    { EOWNERDEAD, 130 },
    { ENOTRECOVERABLE, 131 },
    { ENOSTR, 60 },
    { ENODATA, 61 },
    { ETIME, 62 },
    { ENOSR, 63 },
    { EOPNOTSUPP, 95 },
    { EWOULDBLOCK, 11 },
    { ENOTSUP, 95 },
#if defined(__EMSCRIPTEN__)
    // Linux numbers that wasi-libc does not define
    { EBFONT, 59 },
    { EBADSLT, 57 },
    { EBADRQC, 56 },
    { ENOANO, 55 },
    { ENOTBLK, 15 },
    { ECHRNG, 44 },
    { EL3HLT, 46 },
    { EL3RST, 47 },
    { ELNRNG, 48 },
    { EUNATCH, 49 },
    { ENOCSI, 50 },
    { EL2HLT, 51 },
    { EBADE, 52 },
    { EBADR, 53 },
    { EXFULL, 54 },
    { ENONET, 64 },
    { ENOPKG, 65 },
    { EREMOTE, 66 },
    { EADV, 68 },
    { ESRMNT, 69 },
    { ECOMM, 70 },
    { EDOTDOT, 73 },
    { ENOTUNIQ, 76 },
    { EBADFD, 77 },
    { EREMCHG, 78 },
    { ELIBACC, 79 },
    { ELIBBAD, 80 },
    { ELIBSCN, 81 },
    { ELIBMAX, 82 },
    { ELIBEXEC, 83 },
    { ERESTART, 85 },
    { ESTRPIPE, 86 },
    { EUSERS, 87 },
    { ESOCKTNOSUPPORT, 94 },
    { EPFNOSUPPORT, 96 },
    { ESHUTDOWN, 108 },
    { ETOOMANYREFS, 109 },
    { EHOSTDOWN, 112 },
    { EUCLEAN, 117 },
    { ENOTNAM, 118 },
    { ENAVAIL, 119 },
    { EISNAM, 120 },
    { EREMOTEIO, 121 },
    { ENOMEDIUM, 123 },
    { EMEDIUMTYPE, 124 },
    { ENOKEY, 126 },
    { EKEYEXPIRED, 127 },
    { EKEYREVOKED, 128 },
    { EKEYREJECTED, 129 },
    { ERFKILL, 132 },
    { EL2NSYNC, 45 },
    { EDEADLOCK, 35 },
    { EHWPOISON, 133 },
#endif
};

// The table indexed both ways, built once: hostErrno() and localErrno() are
// called on every file operation, and with 0 when all went well.  Each slot
// holds the first entry of the table for its value (the pairs that share a
// number, EAGAIN/EWOULDBLOCK, EOPNOTSUPP/ENOTSUP, EDEADLK/EDEADLOCK, map to
// the same value), and -1 when the table has none: those values, and those out
// of range, go through unchanged, as when the table was scanned.
class WasmErrnoIndex
{
 public:
    WasmErrnoIndex()
    {
        const size_t count = sizeof(wasmErrnoTable) / sizeof(wasmErrnoTable[0]);
        toHostSize = toLocalSize = 0;
        for (size_t i = 0; i < count; i++)
        {
            if (wasmErrnoTable[i].wasm >= toHostSize)
            {
                toHostSize = wasmErrnoTable[i].wasm + 1;
            }
            if (wasmErrnoTable[i].host >= toLocalSize)
            {
                toLocalSize = wasmErrnoTable[i].host + 1;
            }
        }
        toHost = new int[toHostSize];
        toLocal = new int[toLocalSize];
        for (int i = 0; i < toHostSize; i++)
        {
            toHost[i] = -1;
        }
        for (int i = 0; i < toLocalSize; i++)
        {
            toLocal[i] = -1;
        }
        for (size_t i = 0; i < count; i++)
        {
            if (wasmErrnoTable[i].wasm >= 0 && toHost[wasmErrnoTable[i].wasm] == -1)
            {
                toHost[wasmErrnoTable[i].wasm] = wasmErrnoTable[i].host;
            }
            if (wasmErrnoTable[i].host >= 0 && toLocal[wasmErrnoTable[i].host] == -1)
            {
                toLocal[wasmErrnoTable[i].host] = wasmErrnoTable[i].wasm;
            }
        }
    }

    static int lookup(const int *map, int size, int e)
    {
        if (e < 0 || e >= size || map[e] == -1)
        {
            return e;
        }
        return map[e];
    }

    // never freed: errno values may still be translated while the process exits
    static const WasmErrnoIndex &get()
    {
        static const WasmErrnoIndex *index = new WasmErrnoIndex();
        return *index;
    }

    int *toHost;
    int *toLocal;
    int toHostSize;
    int toLocalSize;
};
#endif

int SysProcess::hostErrno(int e)
{
#if defined(ORX_WASM)
    if (e != 0)
    {
        const WasmErrnoIndex &index = WasmErrnoIndex::get();
        return WasmErrnoIndex::lookup(index.toHost, index.toHostSize, e);
    }
#endif
    return e;
}

int SysProcess::localErrno(int e)
{
#if defined(ORX_WASM)
    if (e != 0)
    {
        const WasmErrnoIndex &index = WasmErrnoIndex::get();
        return WasmErrnoIndex::lookup(index.toLocal, index.toLocalSize, e);
    }
#endif
    return e;
}


#ifdef HAVE_KERN_PROC_ARGV
/**
 * Work out where a program was actually started from, given only the name it
 * was started under. Needed on OpenBSD, which offers neither a procfs nor a
 * sysctl for the executable path, leaving argv[0] as the only clue.
 *
 * argv[0] is a name, not a location. A shell running "rexx prog.rex" passes
 * just "rexx", so the name has to be resolved the same way execvp() resolved
 * it when the program was started: used directly if it contains a slash,
 * looked up along PATH otherwise.
 *
 * Only a candidate that exists and is executable is accepted, so a wrong guess
 * produces no answer rather than a plausible but false path.
 *
 * This inherits the limits of argv[0]. A caller that has already changed
 * directory, or altered PATH, or was handed a deliberately misleading argv[0],
 * can defeat it. That is why an absolute argv[0] is still preferred over this,
 * and why the result must always be verified before use.
 *
 * @param name         The name the program was invoked under.
 * @param resolved     Buffer for the resulting path.
 * @param resolvedSize Size of that buffer.
 *
 * @return true if a candidate was found, false otherwise.
 */
static bool resolveProgramName(const char *name, char *resolved, size_t resolvedSize)
{
    resolved[0] = '\0';
    if (name == NULL || *name == '\0')
    {
        return false;
    }

    // A name containing a slash is a path already, relative to the current
    // directory. execvp() does not search PATH for these, so neither do we.
    if (strchr(name, '/') != NULL)
    {
        if (access(name, X_OK) != 0 ||
            (size_t)snprintf(resolved, resolvedSize, "%s", name) >= resolvedSize)
        {
            resolved[0] = '\0';
            return false;
        }
        return true;
    }

    const char *pathList = getenv("PATH");
    if (pathList == NULL)
    {
        return false;
    }

    // Walk PATH taking the first entry that yields an executable, which is the
    // one the kernel would have run.
    while (true)
    {
        const char *separator = strchr(pathList, ':');
        size_t length = (separator == NULL) ? strlen(pathList) : (size_t)(separator - pathList);

        // An empty entry means the current directory, the same convention
        // execvp() follows.
        int written = (length == 0)
            ? snprintf(resolved, resolvedSize, "./%s", name)
            : snprintf(resolved, resolvedSize, "%.*s/%s", (int)length, pathList, name);

        if (written > 0 && (size_t)written < resolvedSize && access(resolved, X_OK) == 0)
        {
            return true;
        }

        if (separator == NULL)
        {
            break;
        }
        pathList = separator + 1;
    }

    resolved[0] = '\0';
    return false;
}
#endif

/**
 * Get the current user name information.
 *
 * @param buffer The buffer (of at least MAX_USERID_LENGTH characters) into
 * which the userid is copied.
 */
void SysProcess::getUserID(char *buffer)
{
    uid_t uid = geteuid();
    struct passwd *pstUsrDat = getpwuid(uid);
    // a uid without a passwd entry (e.g. a container run with --user 12345)
    // has no name: use the number, as the rxapi service name does
    if (pstUsrDat == NULL)
    {
        snprintf(buffer, MAX_USERID_LENGTH, "%u", (unsigned int)uid);
        return;
    }
    strncpy(buffer, pstUsrDat->pw_name, MAX_USERID_LENGTH-1);
    buffer[MAX_USERID_LENGTH-1] = '\0';
}


/**
 * Determine the location of the running program. This returns the path
 * of the current executable.
 *
 * @return A character string of the location (does not need to be freed by the caller)
 */
const char* SysProcess::getExecutableFullPath()
{
    if (executableFullPath != NULL)
    {
        return executableFullPath;
    }

    char path[PATH_MAX] = ""; // we have no valid path yet
    const char *path_p = path;

#if defined(ORX_WASM)
    // WASM: the path the host gives (SysWasmHost.hpp), if any; realpath()
    // below fails if this file system cannot see it, and the result is NULL
    // (.nil), as with no path at all.
    if (orxWasmExecutablePath != NULL && !orxWasmExecutablePath(path, sizeof(path)))
    {
        path[0] = '\0';
    }
#else
    // run Darwin/Solaris/BSD-specific functions to retrieve the path
    // in some cases they may fail to retrieve a valid path (e. g. on
    // NetBSD where HAVE_KERN_PROC_PATHNAME is defined, sysctl succeeds,
    // but returns len == 0)
#ifdef HAVE_NSGETEXECUTABLEPATH
    // Darwin
    uint32_t length = sizeof(path);
    if (_NSGetExecutablePath(path, &length) != 0)
    {
        path[0] = '\0';
    }
#elif defined HAVE_GETEXECNAME
    // Solaris/OpenIndiana
    path_p = getexecname();
    if (path_p == NULL)
    {
        path_p = path;
        path[0] = '\0';
    }
#elif defined HAVE_KERN_PROC_PATHNAME
    // FreeBSD, DragonFly BSD
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PATHNAME, -1};
    size_t len = PATH_MAX;
    if (sysctl(mib, 4, path, &len, NULL, 0) == -1 || len == 0)
    {
        // sysctl has failed or len was returned as zero, maybe this is
        // NetBSD which uses different arguments
        mib[1] = KERN_PROC_ARGS;
        mib[2] = -1;
        mib[3] = KERN_PROC_PATHNAME;
        len = PATH_MAX;
        if (sysctl(mib, 4, path, &len, NULL, 0) == -1 || len == 0)
        {
            path[0] = '\0';
        }
    }
#elif defined HAVE_KERN_PROC_ARGV
    // OpenBSD
    // https://github.com/ziglang/zig/issues/6718#issuecomment-711134120
    // no means to retrieve the executable path, need to resort to argv[0]
    int mib[4] = {CTL_KERN, KERN_PROC_ARGS, getpid(), KERN_PROC_ARGV};
    size_t len;
    char **argv;
    path[0] = '\0';
    if (sysctl(mib, 4, NULL, &len, NULL, 0) != -1 &&
       (argv = (char **)malloc(len)) != NULL)
    {
        if (sysctl(mib, 4, argv, &len, NULL, 0) != -1 && len > 0)
        {
            // An absolute argv[0] is the reliable case and is taken as is.
            // snprintf rather than strcpy because argv[0] is supplied by
            // whoever started us and is not bounded by PATH_MAX.
            if (argv[0][0] == '/')
            {
                if ((size_t)snprintf(path, sizeof(path), "%s", argv[0]) >= sizeof(path))
                {
                    path[0] = '\0';
                }
            }
            else
            {
                // Anything else is a name rather than a location, which is the
                // ordinary case: a shell running "rexx prog.rex" passes just
                // "rexx". Previously this was given up on, so every ooRexx
                // started through PATH on OpenBSD had no executable path at
                // all and .rexxInfo~executable came back as .nil.
                resolveProgramName(argv[0], path, sizeof(path));
            }
        }
        free(argv);
    }
#endif

    // if we have no OS-specific functions defined, or they failed to
    // retrieve a valid path, try procfs
    if (path[0] == '\0')
    {
        const char *procfs[4];
        char proc_path[32];

        procfs[0] = "/proc/self/exe";     // Linux, NetBSD
        procfs[1] = "/proc/curproc/exe";  // NetBSD
        procfs[2] = "/proc/curproc/file"; // FreeBSD, DragonFly BSD
        snprintf(proc_path, sizeof(proc_path), "/proc/%d/path/a.out", getpid());
        procfs[3] = proc_path;            // Solaris/OpenIndiana

        ssize_t bytes = 0;
        for (int i = 0; i < sizeof(procfs) / sizeof(procfs[0]) && bytes == 0; i++)
        {
            bytes = readlink(procfs[i], path, sizeof(path));
            if (bytes == -1 || bytes == sizeof(path))
            {
                bytes = 0;
            }
        }
        path[bytes] = '\0'; // we must always add a trailing NUL
    }
#endif // ORX_WASM

    // this is the file location with any symbolic links resolved.
    char *modulePath = realpath(path_p, NULL);
    if (modulePath == NULL)
    {
        return NULL;
    }

    // save this for future use
    executableFullPath = modulePath;
    return executableFullPath;
}


/**
 * Determine the location of the Rexx shared libraries. This returns the
 * directory portion of the library path with a trailing slash.
 *
 * @return A character string of the location (does not need to be freed by the caller)
 */
const char* SysProcess::getLibraryLocation()
{
    if (libraryLocation != NULL)
    {
        return libraryLocation;
    }

#if defined(ORX_WASM)
    // WASM: the directory the host gives (SysWasmHost.hpp), if this file
    // system can see it
    char dir[PATH_MAX];
    if (orxWasmLibraryDirectory != NULL && orxWasmLibraryDirectory(dir, sizeof(dir)) && access(dir, F_OK) == 0)
    {
        char *resolved = realpath(dir, NULL);
        if (resolved != NULL)
        {
            size_t len = strlen(resolved);
            char *location = (char *)malloc(len + 2);
            if (location != NULL)
            {
                memcpy(location, resolved, len);
                if (len == 0 || location[len - 1] != '/')
                {
                    location[len++] = '/';
                }
                location[len] = '\0';
                libraryLocation = location;
            }
            free(resolved);
        }
    }
    return libraryLocation;
#elif defined(HAVE_DLADDR)
    Dl_info dlInfo;
    if (dladdr((void *)RexxCreateQueue, &dlInfo) == 0)
    {
        // a zero return means this could not be resolved. Should
        // not be possible, but we'll just return NULL.
        return NULL;
    }

    // this is the file location with any symbolic links
    // resolved.
    char *modulePath = realpath(dlInfo.dli_fname, NULL);

    size_t pathLength = strlen(modulePath);

    // scan backwards to find the last directory delimiter
    for (; pathLength > 0; pathLength--)
    {
        // is this the directory delimiter?
        if (modulePath[pathLength - 1] == '/')
        {
            // terminate the string after the first encountered slash and quit
            modulePath[pathLength] = '\0';
            break;
        }
    }

    // belt-and-braces, make sure we found a directory
    if (pathLength == 0)
    {
        free(modulePath);
        return NULL;
    }

    // save this for future use
    libraryLocation = modulePath;
    return libraryLocation;
#else
    // no means to determine this, so we always return NULL
    return NULL;
#endif
}


/**
 * Sound the speaker.
 *
 * @param frequency The frequency to beep at
 * @param duration  The duration to beep (in milliseconds)
 *
 * @return true if we were able to play this, false otherwise
 */
bool SysProcess::playSpeaker(int frequency, int duration)
{
#ifdef HAVE_KDMKTONE

    const char *console[] =
    {
        "/dev/tty0",
        "/dev/tty1",
        "/dev/tty",
        "/dev/console",
        "/dev/vc/0"
    };

    int fd;
    int io = -1;

    // We need a file descriptor to run ioctl on the console, which will
    // typically require root access rights.  Try a few devices and see
    // if we can successfully open one of them.
    for (int i = 0; i < sizeof(console) / sizeof(console[0]) && io < 0; i++)
    {
        // according to the docs open() may have unwanted side effects
        // that can be avoided under Linux with the O_NONBLOCK flag
        fd = open(console[i], O_RDWR | O_NONBLOCK);
        if (fd >= 0)
        {
            // test KDMKTONE with zero just to see whether this will work
            io = ioctl(fd, KDMKTONE, 0);
            if (io >=0)
            {
                // 1193180 is the magic number of clock cycles that the docs
                // tell you to use to get a frequency in clock cycles
                int pitch = 1193180 / frequency;
                ioctl(fd, KDMKTONE, (duration << 16) | pitch);

                // the sound is on, now wait for duration milliseconds
                // MAX_DURATION is 60000, so there can be no overflow
                SysThread::longSleep(duration * 1000);

                // turn sound off again
                ioctl(fd, KDMKTONE, 0);

                close(fd);
                return true;
            }
            close(fd);
        }
    }
#endif
    // not available, need to use the low tech version
    return false;
}



/**
 * do a beep tone
 *
 * @param frequency The frequency to beep at
 * @param duration  The duration to beep (in milliseconds)
 */
void SysProcess::beep(int frequency, int duration)
{
    // try to directly activate the speaker. If this fails, just send a bell
    // character to the console.
    if (!playSpeaker(frequency, duration))
    {
        printf("\a");
    }
}
