/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Copyright (c) 1995, 2004 IBM Corporation. All rights reserved.             */
/* Copyright (c) 2005-2024 Rexx Language Association. All rights reserved.    */
/*                                                                            */
/* This program and the accompanying materials are made available under       */
/* the terms of the Common Public License v1.0 which accompanies this         */
/* distribution. A copy is also available at the following address:           */
/* https://www.oorexx.org/license.html                                        */
/*                                                                            */
/* Redistribution and use in source and binary forms, with or                 */
/* without modification, are permitted provided that the following            */
/* conditions are met:                                                        */
/*                                                                            */
/* Redistributions of source code must retain the above copyright             */
/* notice, this list of conditions and the following disclaimer.              */
/* Redistributions in binary form must reproduce the above copyright          */
/* notice, this list of conditions and the following disclaimer in            */
/* the documentation and/or other materials provided with the distribution.   */
/*                                                                            */
/* Neither the name of Rexx Language Association nor the names                */
/* of its contributors may be used to endorse or promote products             */
/* derived from this software without specific prior written permission.      */
/*                                                                            */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        */
/* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          */
/* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          */
/* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   */
/* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED   */
/* TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,        */
/* OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY     */
/* OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING    */
/* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS         */
/* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.               */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/******************************************************************************/
/* REXX Shared runtime                                                        */
/*                                                                            */
/* Unix implementation of the SysLibrary                                      */
/*                                                                            */
/******************************************************************************/

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include "SysLibrary.hpp"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <dlfcn.h>


#if defined(ORX_WASM)
// There is no dlopen in WebAssembly.  A build may instead link libraries in
// and describe them with this table (a weak symbol: NULL in the builds that
// link none): load() finds a library by name, getProcedure() a symbol in it,
// so ::METHOD ... EXTERNAL "LIBRARY name ...", RxFuncAdd() and the
// Rexx*Dll() registrations work for them unchanged.  A library may take
// several entries (one per source file); the table ends with a NULL name.
extern "C"
{
typedef struct { const char *name; void *address; } OrxWasmStaticSymbol;
typedef struct { const char *name; const OrxWasmStaticSymbol *symbols; } OrxWasmStaticLibrary;
const OrxWasmStaticLibrary *orx_wasm_static_libraries(void) __attribute__((weak));
}

/**
 * Return the first static library entry called name, or NULL.
 */
static const OrxWasmStaticLibrary *findStaticLibrary(const char *name)
{
    if (orx_wasm_static_libraries == NULL)
    {
        return NULL;
    }
    for (const OrxWasmStaticLibrary *l = orx_wasm_static_libraries(); l->name != NULL; l++)
    {
        if (strcmp(l->name, name) == 0)
        {
            return l;
        }
    }
    return NULL;
}

/**
 * Is this handle one of the static library entries?
 */
static bool isStaticLibrary(void *handle)
{
    if (handle == NULL || orx_wasm_static_libraries == NULL)
    {
        return false;
    }
    for (const OrxWasmStaticLibrary *l = orx_wasm_static_libraries(); l->name != NULL; l++)
    {
        if ((void *)l == handle)
        {
            return true;
        }
    }
    return false;
}
#endif

#define MAX_LIBRARY_NAME_LENGTH 250
#define LIBARY_NAME_BUFFER_LENGTH (1 + MAX_LIBRARY_NAME_LENGTH + sizeof("/usr/lib/lib") + sizeof(ORX_SHARED_LIBRARY_EXT))

SysLibrary::SysLibrary()
{
    libraryHandle = NULL;
}


void * SysLibrary::getProcedure(
  const char *name)                      /* required procedure name           */
/******************************************************************************/
/* Function:  Resolve a named procedure in a library                          */
/******************************************************************************/
{
#if defined(ORX_WASM)
    if (isStaticLibrary(libraryHandle))
    {
        const char *library = ((const OrxWasmStaticLibrary *)libraryHandle)->name;
        for (const OrxWasmStaticLibrary *l = (const OrxWasmStaticLibrary *)libraryHandle; l->name != NULL; l++)
        {
            if (strcmp(l->name, library) != 0)
            {
                continue;
            }
            for (const OrxWasmStaticSymbol *s = l->symbols; s->name != NULL; s++)
            {
                if (strcmp(s->name, name) == 0)
                {
                    return s->address;
                }
            }
        }
        return NULL;
    }
#endif
    return dlsym(libraryHandle, name);
}


bool SysLibrary::load(
    const char *name)                    /* required library name             */
/******************************************************************************/
/* Function:  Load a named library, returning success/failure flag            */
/******************************************************************************/
{
    char nameBuffer[LIBARY_NAME_BUFFER_LENGTH];

    if (strlen(name) > MAX_LIBRARY_NAME_LENGTH)
    {
        return false;
    }

#if defined(ORX_WASM)
    const OrxWasmStaticLibrary *linkedIn = findStaticLibrary(name);
    if (linkedIn != NULL)
    {
        libraryHandle = (void *)linkedIn;
        return true;
    }
#endif

    snprintf(nameBuffer, LIBARY_NAME_BUFFER_LENGTH, "lib%s%s", name, ORX_SHARED_LIBRARY_EXT);
    // try loading directly
    libraryHandle = dlopen(nameBuffer, RTLD_LAZY);
    // if not found, then try from /usr/lib
    if (libraryHandle == NULL)
    {
        snprintf(nameBuffer, LIBARY_NAME_BUFFER_LENGTH, "/usr/lib/lib%s%s", name, ORX_SHARED_LIBRARY_EXT);
        libraryHandle = dlopen(nameBuffer, RTLD_LAZY);
        // still can't find it?
        if (libraryHandle == NULL)
        {
            return false;
        }
    }
    return true;     // loaded successfully
}


/**
 * Free a loaded library if the library is still loaded.
 *
 * @return True if we unloaded ok, false otherwise.
 */
bool SysLibrary::unload()
{
#if defined(ORX_WASM)
    if (isStaticLibrary(libraryHandle))
    {
        return true;           // linked in: nothing to unload
    }
#endif
    if (libraryHandle != NULL)
    {
        dlclose(libraryHandle);
        return true;
    }
    return false;
}
