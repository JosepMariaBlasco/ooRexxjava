/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Copyright (c) 1995, 2004 IBM Corporation. All rights reserved.             */
/* Copyright (c) 2005-2014 Rexx Language Association. All rights reserved.    */
/*                                                                            */
/* This program and the accompanying materials are made available under       */
/* the terms of the Common Public License v1.0 which accompanies this         */
/* distribution. A copy is also available at the following address:           */
/* https://www.oorexx.org/license.html                                        */
/*                                                                            */
/* Redistribution and use in source and binary forms, with or                 */
/* without modification, are permitted provided that the following            */
/* conditions are met:                                                        */
/*                                                                            */
/* Redistributions of source code must retain the above copyright             */
/* notice, this list of conditions and the following disclaimer.              */
/* Redistributions in binary form must reproduce the above copyright          */
/* notice, this list of conditions and the following disclaimer in            */
/* the documentation and/or other materials provided with the distribution.   */
/*                                                                            */
/* Neither the name of Rexx Language Association nor the names                */
/* of its contributors may be used to endorse or promote products             */
/* derived from this software without specific prior written permission.      */
/*                                                                            */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        */
/* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          */
/* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          */
/* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   */
/* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED   */
/* TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,        */
/* OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY     */
/* OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING    */
/* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS         */
/* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.               */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/******************************************************************************/
/* REXX Kernel                                                    DoBlock.hpp */
/*                                                                            */
/* Runtime processing of DO/LOOP variations.  This holds the state of active  */
/* loops and performs loop test operations.                                   */
/*                                                                            */
/******************************************************************************/
#ifndef Included_DoBlock
#define Included_DoBlock

#include "Token.hpp"

class RexxBlockInstruction;
class RexxVariableBase;
class RexxInstructionCatch;
class RexxInstruction;

/**
 * What goes on when the code of a FINALLY clause reaches the END of
 * its block: the reason control was leaving the block (RFE #31).
 */
typedef enum
{
    FINALLY_NONE,          // the code of the clause is not running
    FINALLY_END,           // the block ended by itself: go on after the END
    FINALLY_LEAVE,         // LEAVE of an outer block
    FINALLY_ITERATE,       // ITERATE of an outer loop
    FINALLY_RETURN,        // RETURN
    FINALLY_EXIT,          // EXIT
    FINALLY_SIGNAL,        // SIGNAL instruction
    FINALLY_SIGNAL_TRAP,   // a SIGNAL ON trap
    FINALLY_CATCH,         // a condition caught by a CATCH clause of an outer block
    FINALLY_CONDITION,     // a condition that goes out of this activation
    FINALLY_RAISE,         // RAISE ... RETURN
    FINALLY_RAISE_EXIT,    // RAISE ... EXIT
} FinallyAction;

/**
 * A container for state of active block instructions (DO LOOP, or SELECT)
 */
class DoBlock : public RexxInternalObject
{
 public:

    void *operator new(size_t);
    inline void  operator delete(void *) { ; }

    DoBlock(RexxActivation *context, RexxBlockInstruction *i);
    inline DoBlock(RESTORETYPE restoreType) { ; };

    void live(size_t) override;
    void liveGeneral(MarkReason reason) override;

    inline RexxBlockInstruction* getParent() { return this->parent;};
    inline void setPrevious(DoBlock *block) { previous = block; }
    inline DoBlock* getPrevious() { return previous; }

    inline void setControl(RexxVariableBase *v) { control = v; }
    inline void setTo(RexxObject *value) { to = value;};
    inline void setBy(RexxObject *value) { by = value;};
    inline void setFor(size_t value) { forCount = value;};
    inline void setOverIndex(size_t value) { overIndex = value;};
    inline void setCase(RexxObject *value) { to = value;};
    inline void setSupplier(RexxObject *value) { to = value;};
    inline void setCompare(TokenSubclass value) { compare = value;};
    inline RexxObject* getCase() { return to; }
    inline RexxObject* getSupplier() { return to; }
    inline size_t getIndent() { return indent; };
    inline bool checkFor() { return counter <= forCount; };
    bool checkControl(RexxActivation *context, ExpressionStack *stack, bool increment);
    bool checkOver(RexxActivation *context, ExpressionStack *stack);
    inline void newIteration() { counter++; };
    void setCounter(RexxActivation *context);

    // CATCH clauses (RFE #31)
    inline void setCatches(RexxInstructionCatch *c) { catches = c; }
    inline RexxInstructionCatch *getCatches() { return catches; }
    inline void setInCatch(bool v) { inCatch = v; }
    inline bool isInCatch() { return inCatch; }
    inline void setNest(size_t n) { nest = n; }
    inline size_t getNest() { return nest; }

    // FINALLY clause
    inline RexxInstructionCatch *getFinally() { return finallyClause; }
    inline void setFinally(RexxInstructionCatch *c) { finallyClause = c; }
    inline bool isInFinally() { return inFinally; }
    inline void setInFinally(bool v) { inFinally = v; }
    // the block has a FINALLY clause that has not started yet
    inline bool hasFinallyToRun() { return finallyClause != OREF_NULL && !inFinally; }
    inline void setPending(FinallyAction a, RexxInternalObject *o, RexxInstruction *i, DoBlock *b, RexxInstruction *c)
    {
        pendingAction = a;
        pendingObject = o;
        pendingInstruction = i;
        pendingBlock = b;
        pendingCurrent = c;
    }
    inline FinallyAction getPendingAction() { return pendingAction; }
    inline RexxInternalObject *getPendingObject() { return pendingObject; }
    inline RexxInstruction *getPendingInstruction() { return pendingInstruction; }
    inline DoBlock *getPendingBlock() { return pendingBlock; }
    inline RexxInstruction *getPendingCurrent() { return pendingCurrent; }


protected:

    DoBlock           *previous;         // previous stacked Do Block
    RexxBlockInstruction *parent;        // parent instruction
    size_t             indent;           // base indentation

    // start of variables representing control state.  This get
    // initialized by the loop instruction and are used by block test
    // operations.
    RexxVariableBase  *control;          // control variable for controlled loop
    RexxObject        *to;               // final target TO value
    RexxObject        *by;               // control increment value
    size_t             overIndex;        // index position for a DO OVER
    size_t             forCount;         // number of iterations
    TokenSubclass      compare;          // type of comparison
    RexxVariableBase  *countVariable;    // control variable for counter
    uint64_t           counter;          // the loop iteration counter

    RexxInstructionCatch *catches;       // first CATCH clause of the block, if any
    bool               inCatch;          // the code of a CATCH clause is running
    size_t             nest;             // block nesting level of the block's body

    RexxInstructionCatch *finallyClause; // FINALLY clause of the block, if any
    bool               inFinally;        // the code of the FINALLY clause is running
    FinallyAction      pendingAction;    // what goes on when that code reaches the END...
    RexxInternalObject *pendingObject;   // ...a result, a block name, a condition object
    RexxInstruction   *pendingInstruction; // ...a SIGNAL target, a CATCH clause
    DoBlock           *pendingBlock;     // ...the block of that CATCH clause
    RexxInstruction   *pendingCurrent;   // ...and the instruction that was leaving the block
};
#endif
