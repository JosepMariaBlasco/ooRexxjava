/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Copyright (c) 2026 Rexx Language Association. All rights reserved.         */
/*                                                                            */
/* This program and the accompanying materials are made available under       */
/* the terms of the Common Public License v1.0 which accompanies this         */
/* distribution. A copy is also available at the following address:           */
/* https://www.oorexx.org/license.html                                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/**
 * WASI: the Rexx API server shared between processes, as natively, over
 * stream connections that the host gives the module (the JVM launcher: Unix
 * domain sockets).  The server is the same executable run as a daemon
 * (rexx --orx-wasm-rxapi), started on first use as rxapi is; the host
 * functions below say whether the host can do it at all, and if it cannot,
 * the client falls back to the in-process server (SysLoopbackConnection),
 * not shared with other processes.  ORX_WASM_RXAPI=inprocess asks for that
 * fallback from the start.
 */

#ifndef SysHostConnection_Included
#define SysHostConnection_Included

#include "ServiceMessage.hpp"
#include <stddef.h>

extern "C"
{
// The host's stream connections, by handle (>= 0; -1: failure).  The
// service is the name of the server for this interpreter version: the host
// makes it a path of its own (a socket only this user can open).
int orxWasiApiAvailable(void);                    // 1: the host can do this
int orxWasiApiConnect(const char *service);
int orxWasiApiListen(const char *service);        // -1 also if a server has it
int orxWasiApiAccept(int handle);
long orxWasiApiRead(int handle, void *buf, size_t size);         // 0: closed
long orxWasiApiWrite(int handle, const void *buf, size_t size);  // all, or -1
void orxWasiApiClose(int handle);
int orxWasiApiStartServer(void);                  // launch the daemon, detached
}


class SysHostConnection : public ApiConnection
{
public:
    inline SysHostConnection(int h = -1) : handle(h), ApiConnection() { }
    inline ~SysHostConnection() { disconnect(); }

    static const char *serviceName();
    bool connect();

    bool read(void *buf, size_t bufsize, size_t *bytesread) override;
    bool write(void *buf, size_t bufsize, size_t *byteswritten) override;
    bool write(void *buf, size_t bufsize, void *buf2, size_t buf2size, size_t *byteswritten) override;
    bool disconnect() override;

protected:
    int handle;
};


class SysHostServerConnectionManager : public ServerConnectionManager
{
public:
    inline SysHostServerConnectionManager() : handle(-1) { }
    inline ~SysHostServerConnectionManager() { disconnect(); }

    bool bind();
    ApiConnection *acceptConnection() override;
    bool disconnect() override;

protected:
    int handle;
};

#endif
