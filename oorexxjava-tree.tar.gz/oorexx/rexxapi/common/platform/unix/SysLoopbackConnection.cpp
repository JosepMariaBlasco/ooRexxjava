/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Copyright (c) 2026 Rexx Language Association. All rights reserved.         */
/*                                                                            */
/* This program and the accompanying materials are made available under       */
/* the terms of the Common Public License v1.0 which accompanies this         */
/* distribution. A copy is also available at the following address:           */
/* https://www.oorexx.org/license.html                                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/**
 * In-process transport to the Rexx API server; see SysLoopbackConnection.hpp.
 */

#include "SysLoopbackConnection.hpp"
#include "ServiceMessage.hpp"
#include "APIServer.hpp"
#include <string.h>

namespace
{
/**
 * The server end of a loopback exchange: reads the pending request and
 * collects the reply.
 */
class ServerEnd : public ApiConnection
{
public:
    ServerEnd(std::vector<char> &in, std::vector<char> &out) : ApiConnection(), input(in), output(out), pos(0) { }

    bool read(void *buf, size_t bufsize, size_t *bytesread) override
    {
        size_t n = input.size() - pos;
        if (n > bufsize)
        {
            n = bufsize;
        }
        memcpy(buf, input.data() + pos, n);
        pos += n;
        *bytesread = n;
        return n > 0 || bufsize == 0;
    }

    bool write(void *buf, size_t bufsize, size_t *byteswritten) override
    {
        output.insert(output.end(), (char *)buf, (char *)buf + bufsize);
        *byteswritten = bufsize;
        return true;
    }

    bool write(void *buf, size_t bufsize, void *buf2, size_t buf2size, size_t *byteswritten) override
    {
        output.insert(output.end(), (char *)buf, (char *)buf + bufsize);
        output.insert(output.end(), (char *)buf2, (char *)buf2 + buf2size);
        *byteswritten = bufsize + buf2size;
        return true;
    }

    bool disconnect() override { return true; }

private:
    std::vector<char> &input;
    std::vector<char> &output;
    size_t pos;
};


/**
 * The single in-process server instance (created on first use).
 */
APIServer &inProcessServer()
{
    static APIServer *server = []()
    {
        APIServer *s = new APIServer();
        s->initServer(NULL);
        return s;
    }();
    return *server;
}
}


/**
 * Run the server on the request collected so far, replacing any old reply.
 */
void SysLoopbackConnection::serve()
{
    reply.clear();
    replyPos = 0;
    ServerEnd end(request, reply);
    ServiceMessage message;
    message.readMessage(&end);
    inProcessServer().processMessage(message);
    message.writeResult(&end);
    request.clear();
}


bool SysLoopbackConnection::read(void *buf, size_t bufsize, size_t *bytesread)
{
    // first read after a request: serve it now, on this thread
    if (replyPos >= reply.size() && !request.empty())
    {
        serve();
    }
    size_t n = reply.size() - replyPos;
    if (n > bufsize)
    {
        n = bufsize;
    }
    memcpy(buf, reply.data() + replyPos, n);
    replyPos += n;
    *bytesread = n;
    if (n == 0 && bufsize != 0)
    {
        errcode = CSERROR_IO_FAILED;
        return false;
    }
    return true;
}


bool SysLoopbackConnection::write(void *buf, size_t bufsize, size_t *byteswritten)
{
    request.insert(request.end(), (char *)buf, (char *)buf + bufsize);
    *byteswritten = bufsize;
    return true;
}


bool SysLoopbackConnection::write(void *buf, size_t bufsize, void *buf2, size_t buf2size, size_t *byteswritten)
{
    request.insert(request.end(), (char *)buf, (char *)buf + bufsize);
    request.insert(request.end(), (char *)buf2, (char *)buf2 + buf2size);
    *byteswritten = bufsize + buf2size;
    return true;
}
