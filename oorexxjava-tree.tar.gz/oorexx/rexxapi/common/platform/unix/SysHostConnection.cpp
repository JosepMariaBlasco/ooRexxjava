/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Copyright (c) 2026 Rexx Language Association. All rights reserved.         */
/*                                                                            */
/* This program and the accompanying materials are made available under       */
/* the terms of the Common Public License v1.0 which accompanies this         */
/* distribution. A copy is also available at the following address:           */
/* https://www.oorexx.org/license.html                                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/**
 * WASI: connections to the shared Rexx API server; see SysHostConnection.hpp.
 */

#include "SysHostConnection.hpp"
#include "APIServer.hpp"
#include "oorexxapi.h"
#include <stdio.h>
#include <string.h>

/**
 * The server's name for this interpreter version (as rxapi's socket name
 * carries none, versions that speak another protocol would meet: the name
 * keeps them apart).
 */
const char *SysHostConnection::serviceName()
{
    static char name[64] = "";
    if (name[0] == '\0')
    {
        snprintf(name, sizeof(name), "rxapi-%d.%d.%d-%d", ORX_VER, ORX_REL, ORX_MOD, REXXAPI_VERSION);
    }
    return name;
}


bool SysHostConnection::connect()
{
    handle = orxWasiApiConnect(serviceName());
    errcode = handle < 0 ? CSERROR_OPEN_FAILED : CSERROR_OK;
    return handle >= 0;
}


bool SysHostConnection::read(void *buf, size_t bufsize, size_t *bytesread)
{
    long actual = handle < 0 ? -1 : orxWasiApiRead(handle, buf, bufsize);
    if (actual < 0)
    {
        errcode = CSERROR_IO_FAILED;
        return false;
    }
    *bytesread = (size_t)actual;
    errcode = CSERROR_OK;
    return true;
}


bool SysHostConnection::write(void *buf, size_t bufsize, size_t *byteswritten)
{
    long actual = handle < 0 ? -1 : orxWasiApiWrite(handle, buf, bufsize);
    if (actual < 0)
    {
        errcode = CSERROR_IO_FAILED;
        return false;
    }
    *byteswritten = (size_t)actual;
    errcode = CSERROR_OK;
    return true;
}


bool SysHostConnection::write(void *buf, size_t bufsize, void *buf2, size_t buf2size, size_t *byteswritten)
{
    size_t first = 0, second = 0;
    if (!write(buf, bufsize, &first))
    {
        return false;
    }
    if (buf2size > 0 && !write(buf2, buf2size, &second))
    {
        return false;
    }
    *byteswritten = first + second;
    return true;
}


bool SysHostConnection::disconnect()
{
    if (handle >= 0)
    {
        orxWasiApiClose(handle);
        handle = -1;
    }
    return true;
}


bool SysHostServerConnectionManager::bind()
{
    handle = orxWasiApiListen(SysHostConnection::serviceName());
    errcode = handle < 0 ? CSERROR_OPEN_FAILED : CSERROR_OK;
    return handle >= 0;
}


ApiConnection *SysHostServerConnectionManager::acceptConnection()
{
    int client = handle < 0 ? -1 : orxWasiApiAccept(handle);
    if (client < 0)
    {
        errcode = CSERROR_IO_FAILED;
        return NULL;
    }
    errcode = CSERROR_OK;
    return new SysHostConnection(client);
}


bool SysHostServerConnectionManager::disconnect()
{
    if (handle >= 0)
    {
        orxWasiApiClose(handle);
        handle = -1;
    }
    return true;
}


/**
 * rexx --orx-wasm-rxapi: the daemon (APIService.cpp's main, over the host's
 * connections).  Returns at once, with 1, if another daemon already serves.
 */
int orxWasiRxapiMain()
{
    SysHostServerConnectionManager *c = new SysHostServerConnectionManager();
    if (!c->bind())
    {
        delete c;
        return 1;
    }
    APIServer *server = new APIServer();
    server->initServer(c);
    server->listenForConnections();
    server->terminateServer();
    return 0;
}
