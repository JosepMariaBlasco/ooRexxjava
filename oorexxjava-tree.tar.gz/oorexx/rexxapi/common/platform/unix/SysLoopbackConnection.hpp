/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Copyright (c) 2026 Rexx Language Association. All rights reserved.         */
/*                                                                            */
/* This program and the accompanying materials are made available under       */
/* the terms of the Common Public License v1.0 which accompanies this         */
/* distribution. A copy is also available at the following address:           */
/* https://www.oorexx.org/license.html                                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/**
 * In-process connection to the Rexx API server (WebAssembly build).
 *
 * A WASM process cannot start or reach the rxapi daemon, so the server code
 * (queues, registrations, macrospace) is linked into the interpreter and the
 * client talks to it through this connection: the request written by
 * ClientMessage is decoded and dispatched on the calling thread when the
 * client starts reading the reply.  The message protocol and the server code
 * are unchanged; only the transport is replaced.
 */
#ifndef SysLoopbackConnection_Included
#define SysLoopbackConnection_Included

#include <stddef.h>
#include <stdlib.h>
#include "CSStream.hpp"
#include <vector>

class SysLoopbackConnection : public ApiConnection
{
public:
    SysLoopbackConnection() : ApiConnection(), replyPos(0) { }
    ~SysLoopbackConnection() { }
    bool read(void *buf, size_t bufsize, size_t *bytesread) override;
    bool write(void *buf, size_t bufsize, size_t *byteswritten) override;
    bool write(void *buf, size_t bufsize, void *buf2, size_t buf2size, size_t *byteswritten) override;
    bool disconnect() override { return true; }

protected:
    void serve();

    std::vector<char> request;   // bytes written by the client, not yet served
    std::vector<char> reply;     // the server's answer
    size_t replyPos;             // read position in the reply
};

#endif
