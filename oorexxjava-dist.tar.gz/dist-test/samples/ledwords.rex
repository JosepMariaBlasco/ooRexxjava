#!@OOREXX_SHEBANG_PROGRAM@
/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Copyright (c) 2026 Rexx Language Association. All rights reserved.         */
/*                                                                            */
/* This program and the accompanying materials are made available under       */
/* the terms of the Common Public License v1.0 which accompanies this         */
/* distribution. A copy is also available at the following address:           */
/* https://www.oorexx.org/license.html                                        */
/*                                                                            */
/* Redistribution and use in source and binary forms, with or                 */
/* without modification, are permitted provided that the following            */
/* conditions are met:                                                        */
/*                                                                            */
/* Redistributions of source code must retain the above copyright             */
/* notice, this list of conditions and the following disclaimer.              */
/* Redistributions in binary form must reproduce the above copyright          */
/* notice, this list of conditions and the following disclaimer in            */
/* the documentation and/or other materials provided with the distribution.   */
/*                                                                            */
/* Neither the name of Rexx Language Association nor the names                */
/* of its contributors may be used to endorse or promote products             */
/* derived from this software without specific prior written permission.      */
/*                                                                            */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        */
/* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          */
/* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          */
/* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   */
/* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED   */
/* TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,        */
/* OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY     */
/* OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING    */
/* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS         */
/* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.               */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/******************************************************************************/
/*  ledwords.rex             Open Object Rexx Samples                         */
/*                                                                            */
/*  An edit macro for ledit.cls: count the words of the buffer                */
/*                                                                            */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/*  Description:                                                              */
/*  This program works on the buffer of ADDRESS LEDIT (see ledit.cls): it     */
/*  counts the lines and the words, displays the count and returns the        */
/*  number of words.  It leaves the current line where it was, as a good      */
/*  macro does.                                                               */
/*                                                                            */
/*  It is meant to be called by another program of the same interpreter       */
/*  instance, which has the buffer, as useledit.rex does:                     */
/*                                                                            */
/*      call "ledwords.rex"                                                   */
/*                                                                            */
/*  Started on its own (rexx ledwords.rex), it has an instance, and so a      */
/*  LEDIT, of its own, with an empty buffer: 0 lines, 0 words.                */
/******************************************************************************/

address ledit                         -- LEDIT is the default environment

"EXTRACT /SIZE/LINE/"                 -- sets SIZE.1 and LINE.1
words = 0
"TOP"
do size.1
  "NEXT"
  "EXTRACT /CURLINE/"
  words += curline.1~words
end
if line.1 == 0 then "TOP"             -- back to the line we started at
else ":"line.1

say "ledwords.rex:" size.1 "lines," words "words"
return words

::requires "ledit.cls"
